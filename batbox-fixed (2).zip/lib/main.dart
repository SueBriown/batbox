import 'dart:async';
import 'dart:convert';
import 'dart:math';
import 'dart:typed_data';

import 'dart:io';

import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:camera/camera.dart';
import 'package:just_audio/just_audio.dart';
import 'package:path_provider/path_provider.dart';
import 'package:permission_handler/permission_handler.dart';
import 'package:record/record.dart';
import 'package:shared_preferences/shared_preferences.dart';

void main() {
  runApp(const BatboxApp());
}

enum RecognitionMode { standard, better }

class BatboxApp extends StatefulWidget {
  const BatboxApp({super.key});

  @override
  State<BatboxApp> createState() => _BatboxAppState();
}

class _BatboxAppState extends State<BatboxApp> {
  final AudioRecorder _audioRecorder = AudioRecorder();
  final AudioPlayer _audioPlayer = AudioPlayer();
  StreamSubscription<dynamic>? _audioSubscription;
  List<CameraDescription> _availableCameras = <CameraDescription>[];
  CameraController? _cameraController;
  Timer? _flashTimer;
  // Lowered from 0.68 -> 0.45. Speaker->mic matching with cosine
  // similarity on downsampled PCM typically peaks at 0.5-0.7 for a
  // true match and 0.1-0.3 for non-matches. 0.68 was only achievable
  // for a direct cable connection. Adjustable via UI slider.
  double _triggerThreshold = 0.45;
  static const String _referenceSamplesKey = 'reference_samples';
  static const String _hasReferenceKey = 'has_reference';

  late SharedPreferences _prefs;
  late StreamSubscription<PlayerState> _playerStateSubscription;

  final RecordConfig _recordConfig = const RecordConfig(
    encoder: AudioEncoder.pcm16bits,
    sampleRate: 44100,
    numChannels: 1,
  );

  final List<double> _referenceSamples = <double>[];
  final List<double> _liveSamples = <double>[];

  // Downsampled (10:1 -> 4410 Hz) buffers for the actual matching.
  // Downsampling acts as a low-pass filter (good for speaker->mic
  // matching since phone speakers barely reproduce >4kHz anyway)
  // and makes step=1 search 100x cheaper than full-rate.
  final List<double> _referenceDown = <double>[];
  final List<double> _liveDown = <double>[];

  // Default to Better mode -- Standard mode only checks 8 positions
  // which is far too coarse for phase-sensitive cosine matching.
  RecognitionMode _recognitionMode = RecognitionMode.better;

  // Diagnostics: track the best similarity seen in the current
  // listening session so the user can see what scores are actually
  // being computed and tune the threshold accordingly.
  double _currentBestSimilarity = 0.0;
  double _sessionPeakSimilarity = 0.0;

  bool _isRecordingReference = false;
  bool _isListening = false;
  bool _hasReference = false;
  bool _photoTriggered = false;
  bool _isCapturingPhoto = false;
  bool _isPlayingReference = false;
  bool _flashActive = false;
  bool _cameraLaunchInProgress = false;
  double _microphoneLevel = 0.0;
  String _status = 'Record a short reference sound to begin.';
  String _lastSavedPhotoPath = '';

  @override
  void initState() {
    super.initState();
    _loadSavedReference();
    _playerStateSubscription = _audioPlayer.playerStateStream.listen((state) {
      if (!mounted) return;
      setState(() {
        _isPlayingReference = state.playing;
      });
      // Explicitly handle completion
      if (state.processingState == ProcessingState.completed) {
        if (mounted) {
          setState(() {
            _isPlayingReference = false;
          });
        }
      }
    });
  }

  @override
  void dispose() {
    _audioSubscription?.cancel();
    _audioSubscription = null;
    _playerStateSubscription.cancel();
    _audioPlayer.dispose();
    // Best-effort stream teardown before disposing the recorder.
    // dispose() is synchronous so we cannot await stopStream() here;
    // the recorder's own dispose() will force-clean the native side.
    try {
      _audioRecorder.dispose();
    } catch (_) {
      // Ignore: best-effort cleanup during teardown.
    }
    _cameraController?.dispose();
    super.dispose();
  }

  Future<void> _requestPermissions() async {
    final microphoneStatus = await Permission.microphone.request();
    final cameraStatus = await Permission.camera.request();

    if (microphoneStatus.isDenied || cameraStatus.isDenied) {
      if (mounted) {
        setState(() {
          _status = 'Microphone and camera permissions are required.';
        });
      }
    }
  }

  Future<void> _loadSavedReference() async {
    _prefs = await SharedPreferences.getInstance();
    final savedSamples = _prefs.getStringList(_referenceSamplesKey);
    final hasReference = _prefs.getBool(_hasReferenceKey) ?? false;

    if (savedSamples != null && savedSamples.isNotEmpty) {
      _referenceSamples.clear();
      _referenceSamples.addAll(savedSamples.map((sample) => double.parse(sample)).toList());
      _hasReference = true;
      _recomputeReferenceDown();
      if (mounted) {
        setState(() {
          _status = 'Loaded your saved reference sound.';
        });
      }
    } else if (hasReference) {
      _hasReference = true;
      if (mounted) {
        setState(() {
          _status = 'Reference available from a previous session.';
        });
      }
    }
  }

  Future<void> _saveReference() async {
    if (_referenceSamples.isEmpty) {
      await _prefs.setStringList(_referenceSamplesKey, <String>[]);
      await _prefs.setBool(_hasReferenceKey, false);
      return;
    }

    await _prefs.setStringList(
      _referenceSamplesKey,
      _referenceSamples.map((sample) => sample.toString()).toList(),
    );
    await _prefs.setBool(_hasReferenceKey, true);
  }

  Future<void> _toggleReferenceRecording() async {
    if (_isRecordingReference) {
      await _stopAudioStream();
      setState(() {
        _isRecordingReference = false;
        _hasReference = _referenceSamples.length > 2000;
        _status = _hasReference
            ? 'Reference sound saved. You can now listen for it.'
            : 'Reference sound was too short. Try again.';
      });
      if (_hasReference) {
        _recomputeReferenceDown();
        await _saveReference();
      }
      return;
    }

    await _requestPermissions();
    if (!await _audioRecorder.hasPermission()) {
      setState(() => _status = 'Microphone permission was not granted.');
      return;
    }

    _referenceSamples.clear();
    _liveSamples.clear();
    _photoTriggered = false;
    _microphoneLevel = 0.0;
    await _prefs.setStringList(_referenceSamplesKey, <String>[]);
    await _prefs.setBool(_hasReferenceKey, false);

    try {
      _audioSubscription?.cancel();
      final stream = await _audioRecorder.startStream(_recordConfig);
      _audioSubscription = stream.listen((Uint8List event) {
        if (!_isRecordingReference) return;
        final bytes = event;
        final chunk = pcm16ToDoubles(bytes);
        _referenceSamples.addAll(chunk);
      });

      setState(() {
        _isRecordingReference = true;
        _status = 'Recording reference sound...';
      });
    } catch (error) {
      setState(() => _status = 'Unable to start reference recording: $error');
    }
  }

  Future<void> _toggleListening() async {
    if (_isListening) {
      await _stopAudioStream();
      await _disposeCamera();
      setState(() {
        _isListening = false;
        _microphoneLevel = 0.0;
        _status = 'Listening stopped.';
      });
      return;
    }

    if (!_hasReference) {
      setState(() => _status = 'Record a reference sound first.');
      return;
    }

    await _requestPermissions();
    if (!await _audioRecorder.hasPermission()) {
      setState(() => _status = 'Microphone permission was not granted.');
      return;
    }

    _photoTriggered = false;
    _isCapturingPhoto = false;
    _sessionPeakSimilarity = 0.0;
    _currentBestSimilarity = 0.0;
    _liveDown.clear();

    // Pre-initialize camera to avoid delay when photo is triggered
    try {
      await _initializeCamera();
    } catch (error) {
      setState(() => _status = 'Failed to initialize camera: $error');
      return;
    }
    
    try {
      _audioSubscription?.cancel();
      final stream = await _audioRecorder.startStream(_recordConfig);
      _audioSubscription = stream.listen((Uint8List event) {
        if (_photoTriggered || _isCapturingPhoto) return;
        _processIncomingChunk(event);
      });

      setState(() {
        _isListening = true;
        _microphoneLevel = 0.0;
        _status = 'Listening for your reference sound...';
      });
    } catch (error) {
      setState(() => _status = 'Unable to start live listening: $error');
      await _disposeCamera();
    }
  }

  Future<void> _stopAudioStream() async {
    // Cancel the Dart-side subscription first so no more chunks are dispatched.
    final subscription = _audioSubscription;
    _audioSubscription = null;
    if (subscription != null) {
      try {
        await subscription.cancel();
      } catch (_) {
        // Swallow: subscription cancel must never block the photo flow.
      }
    }
    // In record 7.x the unified `stop()` handles both file and stream
    // modes (stopStream() was removed in v6). On Android, however,
    // `stop()` after `startStream()` can block indefinitely if the
    // native AudioRecord thread is mid-read -- this is what was freezing
    // the app. Guard with a timeout so a hung native stop can NEVER
    // block the photo flow; we move on and let dispose() clean up later.
    try {
      if (await _audioRecorder.isRecording()) {
        await _audioRecorder.stop().timeout(
          const Duration(seconds: 2),
          onTimeout: () => null,
        );
      }
    } catch (_) {
      // Ignore: not recording, already stopped, or timed out.
    }
  }

  Future<void> _playReferenceSound() async {
    if (!_hasReference || _referenceSamples.isEmpty) {
      setState(() => _status = 'No reference sound to play yet.');
      return;
    }

    if (_isPlayingReference) {
      await _audioPlayer.stop();
      setState(() => _isPlayingReference = false);
      return;
    }

    try {
      final directory = await getTemporaryDirectory();
      final path = '${directory.path}/reference_sound.wav';
      final file = File(path);
      await file.writeAsBytes(await _encodeWav(_referenceSamples));
      await _audioPlayer.setFilePath(path);
      await _audioPlayer.play();
      setState(() => _isPlayingReference = true);
    } catch (error) {
      setState(() => _status = 'Could not play reference sound: $error');
    }
  }

  Future<void> _saveReferenceToFile() async {
    if (_referenceSamples.isEmpty) {
      setState(() => _status = 'No reference to save.');
      return;
    }

    try {
      final dir = await getApplicationDocumentsDirectory();
      final path = '${dir.path}/reference.wav';
      final file = File(path);
      await file.writeAsBytes(await _encodeWav(_referenceSamples));
      setState(() => _status = 'Reference saved to ${file.path}');
    } catch (error) {
      setState(() => _status = 'Failed to save reference: $error');
    }
  }

  Future<void> _loadReferenceFromFile() async {
    try {
      final dir = await getApplicationDocumentsDirectory();
      final path = '${dir.path}/reference.wav';
      final file = File(path);
      if (!await file.exists()) {
        setState(() => _status = 'No saved reference found at ${file.path}');
        return;
      }

      final bytes = await file.readAsBytes();
      final samples = _decodeWavToSamples(bytes);
      if (samples.isEmpty) {
        setState(() => _status = 'No PCM data found in WAV file.');
        return;
      }

      _referenceSamples.clear();
      _referenceSamples.addAll(samples);
      _hasReference = true;
      _recomputeReferenceDown();
      await _saveReference();
      setState(() => _status = 'Reference loaded from ${file.path}');
    } catch (error) {
      setState(() => _status = 'Failed to load reference: $error');
    }
  }

  Future<List<int>> _encodeWav(List<double> samples) async {
    const sampleRate = 44100;
    const blockAlign = 2;
    final sampleCount = samples.length;
    final byteRate = sampleRate * blockAlign;
    final dataSize = sampleCount * 2;
    final buffer = BytesBuilder();

    void writeUint32(int value) {
      buffer.addByte(value & 0xff);
      buffer.addByte((value >> 8) & 0xff);
      buffer.addByte((value >> 16) & 0xff);
      buffer.addByte((value >> 24) & 0xff);
    }

    void writeUint16(int value) {
      buffer.addByte(value & 0xff);
      buffer.addByte((value >> 8) & 0xff);
    }

    buffer.add(utf8.encode('RIFF'));
    writeUint32(36 + dataSize);
    buffer.add(utf8.encode('WAVE'));
    buffer.add(utf8.encode('fmt '));
    writeUint32(16);
    writeUint16(1);
    writeUint16(1);
    writeUint32(44100);
    writeUint32(byteRate);
    writeUint16(blockAlign);
    writeUint16(16);
    buffer.add(utf8.encode('data'));
    writeUint32(dataSize);

    for (final sample in samples) {
      final value = (sample.clamp(-1.0, 1.0) * 32767).round();
      writeUint16(value < 0 ? value + 65536 : value);
    }

    return buffer.takeBytes();
  }

  List<double> _decodeWavToSamples(Uint8List bytes) {
    // Find the 'data' chunk
    final dataTag = utf8.encode('data');
    int dataIndex = -1;
    for (int i = 0; i + 3 < bytes.length; i++) {
      if (bytes[i] == dataTag[0] && bytes[i + 1] == dataTag[1] && bytes[i + 2] == dataTag[2] && bytes[i + 3] == dataTag[3]) {
        dataIndex = i + 4;
        break;
      }
    }

    if (dataIndex < 0 || dataIndex + 4 > bytes.length) return <double>[];

    final byteData = ByteData.sublistView(bytes);
    final dataSize = byteData.getUint32(dataIndex, Endian.little);
    final dataStart = dataIndex + 4;
    final dataEnd = min(bytes.length, dataStart + dataSize);
    if (dataStart >= dataEnd) return <double>[];

    final audioBytes = bytes.sublist(dataStart, dataEnd);
    return pcm16ToDoubles(Uint8List.fromList(audioBytes));
  }

  // Downsample by 10:1 using a simple averaging low-pass filter.
  // This is the standard decimation technique: average N samples,
  // emit one. Reduces 44100Hz -> 4410Hz, which is sufficient for
  // phone-speaker-range audio and makes step=1 search affordable.
  List<double> _downsample(List<double> input, int factor) {
    if (input.isEmpty || factor <= 1) return List<double>.from(input);
    final out = <double>[];
    // (Dart's List has no reserve() method -- it was a Java/C++ habit.
    //  Growable List amortizes appends; for our buffer sizes (~4400
    //  elements) pre-allocation makes no measurable difference.)
    for (var i = 0; i + factor <= input.length; i += factor) {
      double sum = 0.0;
      for (var j = 0; j < factor; j++) {
        sum += input[i + j];
      }
      out.add(sum / factor);
    }
    return out;
  }

  void _recomputeReferenceDown() {
    _referenceDown.clear();
    _referenceDown.addAll(_downsample(_referenceSamples, 10));
    debugPrint('[batbox] reference downsampled: \${_referenceSamples.length} -> \${_referenceDown.length} samples');
  }

  void _processIncomingChunk(Uint8List bytes) {
    final chunkSamples = pcm16ToDoubles(bytes);
    _liveSamples.addAll(chunkSamples);

    final chunkPeak = chunkSamples.fold<double>(0.0, (current, sample) => max(current, sample.abs()));
    if (mounted) {
      setState(() {
        _microphoneLevel = max(_microphoneLevel * 0.65, chunkPeak);
      });
    }

    // Trim the FULL-RATE live buffer in O(N) (single memmove).
    final maxLiveLen = _referenceSamples.length * 2;
    if (_liveSamples.length > maxLiveLen) {
      _liveSamples.removeRange(0, _liveSamples.length - maxLiveLen);
    }

    if (_referenceSamples.isEmpty || _liveSamples.length < 1000) {
      return;
    }

    // Downsample this chunk and append to the downsampled live buffer.
    // We recompute the whole downsampled buffer from _liveSamples each
    // time -- this is O(liveLen/10) which is cheap (~4400 ops for 1s ref).
    _liveDown.clear();
    _liveDown.addAll(_downsample(_liveSamples, 10));

    if (_referenceDown.isEmpty) {
      _recomputeReferenceDown();
    }
    if (_referenceDown.length < 100 || _liveDown.length < _referenceDown.length) {
      return;
    }

    // Trim downsampled live buffer to 2x reference length.
    final maxLiveDownLen = _referenceDown.length * 2;
    if (_liveDown.length > maxLiveDownLen) {
      _liveDown.removeRange(0, _liveDown.length - maxLiveDownLen);
    }

    // Match on the DOWNSAMPLED signals with step=1 (fine search).
    // At 4410 Hz this is 100x cheaper than full-rate, so step=1 is
    // affordable and finds the TRUE best alignment -- critical because
    // cosine similarity on PCM is extremely phase-sensitive.
    final similarity = bestSimilarityScore(_referenceDown, _liveDown, stepOverride: 1);
    if (similarity > _sessionPeakSimilarity) {
      _sessionPeakSimilarity = similarity;
    }
    _currentBestSimilarity = similarity;
    debugPrint('[batbox] sim=\${similarity.toStringAsFixed(3)} peak=\${_sessionPeakSimilarity.toStringAsFixed(3)} threshold=\${_triggerThreshold.toStringAsFixed(2)} liveDown=\${_liveDown.length} refDown=\${_referenceDown.length}');
    if (similarity >= _triggerThreshold) {
      _photoTriggered = true;
      _isCapturingPhoto = true;
      _flashActive = true;
      _flashTimer?.cancel();
      _flashTimer = Timer(const Duration(milliseconds: 250), () {
        if (mounted) {
          setState(() => _flashActive = false);
        }
      });
      if (mounted) {
        setState(() => _status = 'Match detected. Taking photo...');
      }
      // Fire-and-forget, but attach an error handler so an exception
      // never escapes unobserved (which would crash in --release mode).
      unawaited(_triggerPhoto().catchError((Object error) {
        debugPrint('_triggerPhoto failed: $error');
        if (mounted) {
          setState(() {
            _photoTriggered = false;
            _isCapturingPhoto = false;
            _flashActive = false;
            _cameraLaunchInProgress = false;
            _status = 'Trigger failed: $error';
          });
        }
      }));
    }
  }

  Future<void> _takePhoto({String reason = 'manual'}) async {
    if (_cameraLaunchInProgress) {
      return;
    }

    _cameraLaunchInProgress = true;
    if (mounted) {
      setState(() => _status = reason == 'trigger' ? 'Match detected. Taking photo...' : 'Taking photo...');
    }

    try {
      final cameraPermission = await Permission.camera.status;
      if (!cameraPermission.isGranted) {
        final requested = await Permission.camera.request();
        if (!requested.isGranted) {
          if (!mounted) return;
          setState(() => _status = 'Camera permission was not granted.');
          return;
        }
      }

      // Only initialize camera if not already initialized (during listening)
      if (_cameraController == null || !_cameraController!.value.isInitialized) {
        await _initializeCamera().timeout(
          const Duration(seconds: 5),
          onTimeout: () => throw Exception('Camera initialization timed out.'),
        );
      }
      if (_cameraController == null || !_cameraController!.value.isInitialized) {
        throw Exception('Camera initialization failed.');
      }

      // Guard takePicture with a timeout too: if the native camera service
      // is hung (rare, but possible if the audio EventChannel is still
      // draining), we'd rather surface an error than freeze forever.
      final photo = await _cameraController!.takePicture().timeout(
        const Duration(seconds: 5),
        onTimeout: () => throw Exception('Camera capture timed out.'),
      );
      if (!mounted) return;
      final saved = await _saveCapturedPhoto(photo.path);
      if (!mounted) return;
      setState(() {
        _lastSavedPhotoPath = saved.path;
        _status = 'Photo saved to ${saved.path}';
      });
    } catch (error) {
      if (!mounted) return;
      setState(() => _status = 'Could not capture photo: $error');
    } finally {
      _photoTriggered = false;
      _isCapturingPhoto = false;
      // Only dispose camera if we're not listening
      if (!_isListening) {
        await _disposeCamera();
      }
      if (mounted) {
        setState(() => _cameraLaunchInProgress = false);
      }
    }
  }

  Future<void> _manualTrigger() async {
    if (_cameraLaunchInProgress) {
      return;
    }

    await _takePhoto(reason: 'manual');
  }

  Future<void> _triggerPhoto() async {
    if (_cameraLaunchInProgress) {
      return;
    }

    setState(() {
      _isListening = false;
      _photoTriggered = true;
      _isCapturingPhoto = true;
    });

    // Stop the audio stream, but NEVER let a failure here prevent the
    // photo from being taken. The previous version awaited this call
    // without a try/catch, so any error left the app permanently stuck
    // with _photoTriggered/_isCapturingPhoto == true.
    try {
      await _stopAudioStream();
    } catch (error) {
      debugPrint('Failed to stop audio stream during trigger: $error');
    }

    try {
      await _takePhoto(reason: 'trigger');
    } catch (error) {
      if (mounted) {
        setState(() => _status = 'Could not capture photo: $error');
      }
      // Defensive: make sure flags are cleared even if _takePhoto threw
      // before reaching its own finally block.
      _photoTriggered = false;
      _isCapturingPhoto = false;
      if (mounted) {
        setState(() => _cameraLaunchInProgress = false);
      }
    }
  }

  Future<void> _initializeCamera() async {
    if (_cameraController != null && _cameraController!.value.isInitialized) {
      return;
    }

    _availableCameras = await availableCameras();
    if (_availableCameras.isEmpty) {
      throw Exception('No cameras available.');
    }

    final camera = _availableCameras.firstWhere(
      (c) => c.lensDirection == CameraLensDirection.back,
      orElse: () => _availableCameras.first,
    );

    _cameraController = CameraController(camera, ResolutionPreset.medium, enableAudio: false);
    await _cameraController!.initialize();
  }

  Future<void> _disposeCamera() async {
    _cameraController?.dispose();
    _cameraController = null;
  }

  Future<Directory> _photoDirectory() async {
    final dir = await getApplicationDocumentsDirectory();
    final batboxDir = Directory('${dir.path}${Platform.pathSeparator}batbox');
    if (!await batboxDir.exists()) {
      await batboxDir.create(recursive: true);
    }
    return batboxDir;
  }

  Future<File> _saveCapturedPhoto(String sourcePath) async {
    final photoDir = await _photoDirectory();
    final timestamp = DateTime.now().toIso8601String().replaceAll(':', '-');
    final destination = File('${photoDir.path}${Platform.pathSeparator}batbox-$timestamp.jpg');
    return File(sourcePath).copy(destination.path);
  }

  void _showInstructions() {
    showDialog<void>(
      context: context,
      builder: (context) => AlertDialog(
        title: const Text('Instructions'),
        content: const SingleChildScrollView(
          child: Text(
            'Record a short sound, then switch to listening mode. The app will listen for a close match and take a photo automatically when it hears the reference sound.',
          ),
        ),
        actions: [
          TextButton(
            onPressed: () => Navigator.of(context).pop(),
            child: const Text('OK'),
          ),
        ],
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'BatBox',
      theme: ThemeData(colorSchemeSeed: Colors.deepPurple, useMaterial3: true),
      home: Scaffold(
        appBar: AppBar(title: const Text('BatBox')),
        body: Stack(
          children: [
            AnimatedContainer(
              duration: const Duration(milliseconds: 180),
              color: _flashActive ? Colors.black.withValues(alpha: 0.85) : Colors.transparent,
            ),
            SafeArea(
              child: Padding(
                padding: const EdgeInsets.symmetric(horizontal: 24.0, vertical: 12.0),
                child: Column(
                  mainAxisSize: MainAxisSize.min,
                  crossAxisAlignment: CrossAxisAlignment.center,
                  children: [
                    const Text(
                      'Listen for your reference sound and trigger a photo',
                      textAlign: TextAlign.center,
                      style: TextStyle(fontSize: 24, fontWeight: FontWeight.bold),
                    ),
                    const SizedBox(height: 8),
                    // VISIBLE BUILD MARKER -- confirms the new code is running.
                    Container(
                      padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 4),
                      decoration: BoxDecoration(
                        color: Colors.deepPurple.withValues(alpha: 0.15),
                        borderRadius: BorderRadius.circular(6),
                      ),
                      child: const Text(
                        'BUILD v5 - 2026-06-29',
                        style: TextStyle(
                          fontSize: 12,
                          fontWeight: FontWeight.bold,
                          color: Colors.deepPurple,
                        ),
                      ),
                    ),
                    const SizedBox(height: 8),
                    FilledButton.icon(
                      onPressed: _showInstructions,
                      icon: const Icon(Icons.help_outline),
                      label: const Text('Instructions'),
                    ),
                    const SizedBox(height: 16),
                    Wrap(
                      crossAxisAlignment: WrapCrossAlignment.center,
                      spacing: 12,
                      runSpacing: 8,
                      alignment: WrapAlignment.center,
                      children: [
                        const Text('Recognition mode:'),
                        DropdownButton<RecognitionMode>(
                          value: _recognitionMode,
                          items: const [
                            DropdownMenuItem(value: RecognitionMode.standard, child: Text('Standard')),
                            DropdownMenuItem(value: RecognitionMode.better, child: Text('Better')),
                          ],
                          onChanged: (v) {
                            if (v == null) return;
                            setState(() => _recognitionMode = v);
                          },
                        ),
                      ],
                    ),
                    const SizedBox(height: 12),
                    Row(
                      mainAxisAlignment: MainAxisAlignment.center,
                      children: [
                        FilledButton.icon(
                          onPressed: _saveReferenceToFile,
                          icon: const Icon(Icons.save),
                          label: const Text('Save reference'),
                        ),
                        const SizedBox(width: 12),
                        FilledButton.icon(
                          onPressed: _loadReferenceFromFile,
                          icon: const Icon(Icons.folder_open),
                          label: const Text('Load reference'),
                        ),
                      ],
                    ),
                    FilledButton.icon(
                      onPressed: _toggleReferenceRecording,
                      icon: Icon(_isRecordingReference ? Icons.stop : Icons.mic),
                      label: Text(_isRecordingReference ? 'Stop recording reference' : 'Record reference'),
                    ),
                    const SizedBox(height: 12),
                    FilledButton.icon(
                      onPressed: _toggleListening,
                      icon: Icon(_isListening ? Icons.stop_circle : Icons.sensors),
                      label: Text(_isListening ? 'Stop listening' : 'Start listening'),
                    ),
                    const SizedBox(height: 24),
                    if (_hasReference)
                      FilledButton.icon(
                        onPressed: _playReferenceSound,
                        icon: Icon(_isPlayingReference ? Icons.stop : Icons.play_arrow),
                        label: Text(_isPlayingReference ? 'Stop playback' : 'Play reference sound'),
                      ),
                    const SizedBox(height: 12),
                    FilledButton.icon(
                      onPressed: _manualTrigger,
                      icon: const Icon(Icons.camera_alt),
                      label: const Text('Take photo manually'),
                    ),
                    const SizedBox(height: 12),
                    Text(
                      _status,
                      textAlign: TextAlign.center,
                      style: const TextStyle(fontSize: 16),
                    ),
                    if (_lastSavedPhotoPath.isNotEmpty) ...[
                      const SizedBox(height: 12),
                      Text(
                        'Last saved image:\n$_lastSavedPhotoPath',
                        textAlign: TextAlign.center,
                        style: const TextStyle(fontSize: 14),
                      ),
                    ],
                    const SizedBox(height: 12),
                    if (_isListening)
                      Column(
                        children: [
                          Text(
                            'Microphone level: ${(_microphoneLevel * 100).clamp(0.0, 100.0).round()}%',
                            style: Theme.of(context).textTheme.bodyMedium,
                          ),
                          const SizedBox(height: 6),
                          SizedBox(
                            width: 220,
                            child: LinearProgressIndicator(
                              value: _microphoneLevel.clamp(0.0, 1.0),
                              minHeight: 10,
                            ),
                          ),
                          const SizedBox(height: 12),
                          // Live similarity readout -- shows the actual
                          // cosine similarity being computed each chunk,
                          // plus the session peak. If peak stays below
                          // threshold, lower the threshold via the slider
                          // below until it triggers.
                          Text(
                            'Similarity: \${_currentBestSimilarity.toStringAsFixed(3)}  (peak: \${_sessionPeakSimilarity.toStringAsFixed(3)})',
                            style: TextStyle(
                              fontSize: 14,
                              fontWeight: FontWeight.bold,
                              color: _currentBestSimilarity >= _triggerThreshold
                                  ? Colors.green
                                  : Colors.orange,
                            ),
                          ),
                          const SizedBox(height: 8),
                          Text(
                            'Threshold: \${_triggerThreshold.toStringAsFixed(2)}',
                            style: Theme.of(context).textTheme.bodySmall,
                          ),
                          SizedBox(
                            width: 280,
                            child: Slider(
                              value: _triggerThreshold,
                              min: 0.10,
                              max: 0.90,
                              divisions: 80,
                              label: _triggerThreshold.toStringAsFixed(2),
                              onChanged: (v) => setState(() => _triggerThreshold = v),
                            ),
                          ),
                        ],
                      ),
                    const SizedBox(height: 12),
                    Text(
                      'Reference captured: ${_hasReference ? _referenceSamples.length : 0} samples',
                      style: Theme.of(context).textTheme.bodyMedium,
                    ),
                  ],
                ),
              ),
            ),
          ],
        ),
      ),
    );
  }
}

double similarityScore(List<double> reference, List<double> candidate) {
  if (reference.isEmpty || candidate.isEmpty) return 0.0;

  final length = min(reference.length, candidate.length);
  // Read by index instead of allocating two sublists (each O(length)).
  double dotProduct = 0.0;
  double refNorm = 0.0;
  double candNorm = 0.0;

  for (var i = 0; i < length; i++) {
    final r = reference[i];
    final c = candidate[i];
    dotProduct += r * c;
    refNorm += r * r;
    candNorm += c * c;
  }

  if (refNorm == 0 || candNorm == 0) return 0.0;
  return dotProduct / (sqrt(refNorm * candNorm));
}

double bestSimilarityScore(List<double> reference, List<double> liveSamples, {int? stepOverride}) {
  if (reference.isEmpty || liveSamples.isEmpty) return 0.0;

  final targetLength = min(reference.length, liveSamples.length);
  if (targetLength < 10) return similarityScore(reference, liveSamples);

  // In v5 we match on DOWNSAMPLED signals (4410 Hz). At that rate a
  // 1-second reference is 4410 samples, so step=1 search over a 2x
  // buffer is 4410 x 4410 = 19.5M ops/chunk -- affordable. The v3 cap
  // (maxWindows=64) is removed because it made Better mode too coarse
  // and was the reason matching never fired.
  // For Standard mode we still use step = targetLength/8 (8 windows),
  // which is fine as a fast preview.
  final searchSpan = liveSamples.length - targetLength;
  final step = stepOverride ?? max(1, targetLength ~/ 8);

  var bestScore = 0.0;
  for (var start = 0; start <= searchSpan; start += step) {
    final score = similarityScoreRange(reference, liveSamples, start, targetLength);
    if (score > bestScore) {
      bestScore = score;
    }
  }

  return bestScore;
}

// Cosine similarity of reference[0..length) vs live[start..start+length).
// Allocates nothing; reads both lists by index.
double similarityScoreRange(List<double> reference, List<double> live, int start, int length) {
  double dotProduct = 0.0;
  double refNorm = 0.0;
  double candNorm = 0.0;
  for (var i = 0; i < length; i++) {
    final r = reference[i];
    final c = live[start + i];
    dotProduct += r * c;
    refNorm += r * r;
    candNorm += c * c;
  }
  if (refNorm == 0 || candNorm == 0) return 0.0;
  return dotProduct / (sqrt(refNorm * candNorm));
}

List<double> pcm16ToDoubles(Uint8List bytes) {
  final samples = <double>[];
  final byteData = ByteData.sublistView(bytes);
  for (var i = 0; i + 1 < bytes.length; i += 2) {
    final sample = byteData.getInt16(i, Endian.little);
    samples.add(sample / 32768.0);
  }
  return samples;
}
