import 'dart:async';
import 'dart:convert';
import 'dart:math';
import 'dart:typed_data';

import 'dart:io';

import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:camera/camera.dart';
import 'package:file_picker/file_picker.dart';
import 'package:ffmpeg_kit_flutter_new/ffmpeg_kit.dart';
import 'package:ffmpeg_kit_flutter_new/return_code.dart';
import 'package:just_audio/just_audio.dart';
import 'package:path_provider/path_provider.dart';
import 'package:permission_handler/permission_handler.dart';
import 'package:record/record.dart';
import 'package:shared_preferences/shared_preferences.dart';

void main() {
  runApp(const BatboxApp());
}

enum RecognitionMode { standard, better }

/// How many photos to take per match (burst size) and whether to keep listening.
enum PhotoCountMode {
  one('1 photo per match'),
  three('3 photos per match'),
  ten('10 photos per match'),
  continuous('Continuous (1 per match)'),
  flashOnly('Flash only (test)');

  const PhotoCountMode(this.label);
  final String label;

  /// Number of photos to take in a burst when a match is detected.
  int get burstSize {
    switch (this) {
      case PhotoCountMode.one:
        return 1;
      case PhotoCountMode.three:
        return 3;
      case PhotoCountMode.ten:
        return 10;
      case PhotoCountMode.continuous:
        return 1;
      case PhotoCountMode.flashOnly:
        return 0;
    }
  }

  /// Whether to stop listening after the first match's burst completes.
  bool get stopAfterFirstMatch {
    switch (this) {
      case PhotoCountMode.one:
      case PhotoCountMode.three:
      case PhotoCountMode.ten:
        return true;
      case PhotoCountMode.continuous:
      case PhotoCountMode.flashOnly:
        return false;
    }
  }

  /// Whether this mode actually takes photos (false for flashOnly).
  bool get takesPhotos => this != PhotoCountMode.flashOnly;
}

/// Camera flash/torch mode.
enum FlashModeSetting {
  off('Off'),
  auto('Auto'),
  always('Always flash'),
  torch('Torch (continuous)');

  const FlashModeSetting(this.label);
  final String label;
}

class BatboxApp extends StatefulWidget {
  const BatboxApp({super.key});

  @override
  State<BatboxApp> createState() => _BatboxAppState();
}

class _BatboxAppState extends State<BatboxApp> with TickerProviderStateMixin {
  final AudioRecorder _audioRecorder = AudioRecorder();
  final AudioPlayer _audioPlayer = AudioPlayer();
  StreamSubscription<dynamic>? _audioSubscription;
  List<CameraDescription> _availableCameras = <CameraDescription>[];
  CameraController? _cameraController;
  Timer? _flashTimer;
  late TabController _tabController;

  // Matching parameters -- shared across all tabs so tuning on the
  // Reference tab's test mode carries over to the Trigger tab.
  double _triggerThreshold = 0.35;
  RecognitionMode _recognitionMode = RecognitionMode.better;
  PhotoCountMode _photoCountMode = PhotoCountMode.one;
  FlashModeSetting _flashModeSetting = FlashModeSetting.off;

  static const String _referenceSamplesKey = 'reference_samples';
  static const String _hasReferenceKey = 'has_reference';

  late SharedPreferences _prefs;
  late StreamSubscription<PlayerState> _playerStateSubscription;

  final RecordConfig _recordConfig = const RecordConfig(
    encoder: AudioEncoder.pcm16bits,
    sampleRate: 44100,
    numChannels: 1,
  );

  final List<double> _referenceSamples = <double>[];
  final List<double> _liveSamples = <double>[];

  // Downsampled (10:1 -> 4410 Hz) buffers for the actual matching.
  final List<double> _referenceDown = <double>[];
  final List<double> _liveDown = <double>[];

  // Pre-processed reference: pre-emphasized (high-pass filtered) for
  // better spectral matching. Computed once when reference is set.
  final List<double> _referenceProcessed = <double>[];

  // Energy envelope of the reference: RMS energy in 10ms windows.
  // This is phase-invariant and robust to speaker/mic differences.
  // We compare envelopes using normalized cosine similarity for a
  // second, independent match score.
  final List<double> _referenceEnvelope = <double>[];

  // Reference signal energy (RMS), used for silence gating on the
  // live buffer. If the live buffer's energy is far below the
  // reference's, we skip matching entirely (no point comparing
  // silence to a loud reference).
  double _referenceEnergy = 0.0;
  double _silenceThreshold = 0.0;

  // Adaptive noise floor: tracked from quiet passages during listening.
  // Used to raise the effective threshold when the environment is noisy.
  double _adaptiveNoiseFloor = 0.0;

  // Match debouncing: require the similarity to stay above threshold
  // for N consecutive chunks before triggering. Reduces false positives
  // from transient noise.
  int _consecutiveMatchCount = 0;
  static const int _minMatchChunks = 2; // ~200ms at 10 chunks/sec

  // Diagnostics.
  double _currentBestSimilarity = 0.0;
  double _sessionPeakSimilarity = 0.0;

  // Multi-photo mode controls.
  int _photosTakenThisSession = 0;
  int _burstsThisSession = 0;
  static const Duration _refractoryPeriod = Duration(milliseconds: 1500);
  DateTime _lastTriggerTime = DateTime.fromMillisecondsSinceEpoch(0);

  // Test mode: when true, match detection runs and shows similarity,
  // but NO photos are taken. Used by the Reference tab's "Test
  // recognition" feature. Shares all threshold/mode settings with
  // the Trigger tab.
  bool _testMode = false;

  // Photo gallery state.
  final List<String> _capturedPhotoPaths = <String>[];
  final Set<String> _selectedPhotoPaths = <String>{};
  bool _selectionMode = false;

  bool _isRecordingReference = false;
  bool _isListening = false;
  bool _hasReference = false;
  bool _photoTriggered = false;
  bool _isCapturingPhoto = false;
  bool _isPlayingReference = false;
  bool _flashActive = false;
  bool _cameraLaunchInProgress = false;
  double _microphoneLevel = 0.0;
  String _status = 'Record a short reference sound to begin.';
  String _lastSavedPhotoPath = '';
  String _lastAction = 'none'; // visible debug for Photos tab
  @override
  void initState() {
    super.initState();
    _tabController = TabController(length: 3, vsync: this);
    _loadSavedReference();
    _refreshPhotoList();
    _playerStateSubscription = _audioPlayer.playerStateStream.listen((state) {
      if (!mounted) return;
      setState(() {
        _isPlayingReference = state.playing;
      });
      if (state.processingState == ProcessingState.completed) {
        if (mounted) {
          setState(() {
            _isPlayingReference = false;
          });
        }
      }
    });
  }

  @override
  void dispose() {
    _tabController.dispose();
    _audioSubscription?.cancel();
    _audioSubscription = null;
    _playerStateSubscription.cancel();
    _audioPlayer.dispose();
    try {
      _audioRecorder.dispose();
    } catch (_) {}
    _cameraController?.dispose();
    super.dispose();
  }

  Future<void> _requestPermissions() async {
    final microphoneStatus = await Permission.microphone.request();
    final cameraStatus = await Permission.camera.request();
    if (microphoneStatus.isDenied || cameraStatus.isDenied) {
      if (mounted) {
        setState(() {
          _status = 'Microphone and camera permissions are required.';
        });
      }
    }
  }

  Future<void> _loadSavedReference() async {
    _prefs = await SharedPreferences.getInstance();
    final savedSamples = _prefs.getStringList(_referenceSamplesKey);
    final hasReference = _prefs.getBool(_hasReferenceKey) ?? false;

    if (savedSamples != null && savedSamples.isNotEmpty) {
      _referenceSamples.clear();
      _referenceSamples.addAll(savedSamples.map((sample) => double.parse(sample)).toList());
      _hasReference = true;
      _recomputeReferenceDown();
      if (mounted) {
        setState(() {
          _status = 'Loaded your saved reference sound.';
        });
      }
    } else if (hasReference) {
      _hasReference = true;
      if (mounted) {
        setState(() {
          _status = 'Reference available from a previous session.';
        });
      }
    }
  }

  Future<void> _saveReference() async {
    if (_referenceSamples.isEmpty) {
      await _prefs.setStringList(_referenceSamplesKey, <String>[]);
      await _prefs.setBool(_hasReferenceKey, false);
      return;
    }
    await _prefs.setStringList(
      _referenceSamplesKey,
      _referenceSamples.map((sample) => sample.toString()).toList(),
    );
    await _prefs.setBool(_hasReferenceKey, true);
  }

  // ---------------------------------------------------------------------------
  // Reference recording / playback / file I/O
  // ---------------------------------------------------------------------------

  Future<void> _toggleReferenceRecording() async {
    if (_isRecordingReference) {
      await _stopAudioStream();
      setState(() {
        _isRecordingReference = false;
        _hasReference = _referenceSamples.length > 2000;
        _status = _hasReference
            ? 'Reference sound saved. You can now listen for it.'
            : 'Reference sound was too short. Try again.';
      });
      if (_hasReference) {
        _recomputeReferenceDown();
        await _saveReference();
      }
      return;
    }

    await _requestPermissions();
    if (!await _audioRecorder.hasPermission()) {
      setState(() => _status = 'Microphone permission was not granted.');
      return;
    }

    _referenceSamples.clear();
    _liveSamples.clear();
    _referenceDown.clear();
    _referenceProcessed.clear();
    _photoTriggered = false;
    _microphoneLevel = 0.0;
    await _prefs.setStringList(_referenceSamplesKey, <String>[]);
    await _prefs.setBool(_hasReferenceKey, false);

    try {
      _audioSubscription?.cancel();
      final stream = await _audioRecorder.startStream(_recordConfig);
      _audioSubscription = stream.listen((Uint8List event) {
        if (!_isRecordingReference) return;
        final chunk = pcm16ToDoubles(event);
        _referenceSamples.addAll(chunk);
      });
      setState(() {
        _isRecordingReference = true;
        _status = 'Recording reference sound...';
      });
    } catch (error) {
      setState(() => _status = 'Unable to start reference recording: $error');
    }
  }

  Future<void> _playReferenceSound() async {
    if (!_hasReference || _referenceSamples.isEmpty) {
      setState(() => _status = 'No reference sound to play yet.');
      return;
    }
    if (_isPlayingReference) {
      await _audioPlayer.stop();
      setState(() => _isPlayingReference = false);
      return;
    }
    try {
      final directory = await getTemporaryDirectory();
      final path = '${directory.path}/reference_sound.wav';
      final file = File(path);
      await file.writeAsBytes(await _encodeWav(_referenceSamples));
      await _audioPlayer.setFilePath(path);
      await _audioPlayer.play();
      setState(() => _isPlayingReference = true);
    } catch (error) {
      setState(() => _status = 'Could not play reference sound: $error');
    }
  }

  Future<void> _saveReferenceToFile() async {
    if (_referenceSamples.isEmpty) {
      setState(() => _status = 'No reference to save.');
      return;
    }
    try {
      final dir = await getApplicationDocumentsDirectory();
      final path = '${dir.path}/reference.wav';
      final file = File(path);
      await file.writeAsBytes(await _encodeWav(_referenceSamples));
      setState(() => _status = 'Reference saved to ${file.path}');
    } catch (error) {
      setState(() => _status = 'Failed to save reference: $error');
    }
  }

  Future<void> _loadReferenceFromFile() async {
    try {
      final dir = await getApplicationDocumentsDirectory();
      final path = '${dir.path}/reference.wav';
      final file = File(path);
      if (!await file.exists()) {
        setState(() => _status = 'No saved reference found at ${file.path}');
        return;
      }
      final bytes = await file.readAsBytes();
      final samples = _decodeWavToSamples(bytes);
      if (samples.isEmpty) {
        setState(() => _status = 'No PCM data found in WAV file.');
        return;
      }
      _referenceSamples.clear();
      _referenceSamples.addAll(samples);
      _hasReference = true;
      _recomputeReferenceDown();
      await _saveReference();
      setState(() => _status = 'Reference loaded from ${file.path}');
    } catch (error) {
      setState(() => _status = 'Failed to load reference: $error');
    }
  }

  Future<void> _importWavReference() async {
    try {
      final result = await FilePicker.platform.pickFiles(
        type: FileType.audio,
        allowMultiple: false,
        withData: false,
      );
      if (result == null || result.files.isEmpty) return;
      final platformFile = result.files.first;
      final path = platformFile.path;
      if (path == null) {
        setState(() => _status = 'Could not access the picked file.');
        return;
      }
      final file = File(path);
      if (!await file.exists()) {
        setState(() => _status = 'Picked file does not exist.');
        return;
      }

      // Decide whether we need to transcode. WAV files can be decoded
      // directly; anything else (m4a, mp3, etc.) goes through ffmpeg.
      final ext = path.toLowerCase().split('.').last;
      List<double> samples;
      if (ext == 'wav') {
        final bytes = await file.readAsBytes();
        samples = _decodeWavToSamples(bytes);
      } else {
        setState(() => _status = 'Converting ${platformFile.name} to WAV...');
        samples = await _convertAudioToPcmSamples(file);
      }

      if (samples.isEmpty) {
        setState(() => _status = 'No PCM data found in audio file.');
        return;
      }
      if (samples.length < 2000) {
        setState(() => _status = 'Audio too short (need > ~45ms of audio).');
        return;
      }
      _referenceSamples.clear();
      _referenceSamples.addAll(samples);
      _hasReference = true;
      _recomputeReferenceDown();
      await _saveReference();
      setState(() => _status = 'Reference imported: ${platformFile.name}');
      _showSnackBar('Imported ${platformFile.name} (${samples.length} samples)');
    } catch (error) {
      setState(() => _status = 'Failed to import audio: $error');
      _showSnackBar('Import failed: $error');
    }
  }

  /// Convert any audio file (m4a, mp3, ogg, flac, etc.) to PCM samples
  /// using ffmpeg. Produces a 44100Hz mono 16-bit WAV, then decodes it
  /// to doubles via the existing _decodeWavToSamples helper.
  Future<List<double>> _convertAudioToPcmSamples(File sourceFile) async {
    final tempDir = await getTemporaryDirectory();
    final outputPath = '${tempDir.path}/imported_reference.wav';
    // Remove any previous conversion output so ffmpeg doesn't refuse to
    // overwrite (the -y flag handles this, but belt-and-braces).
    final outputFile = File(outputPath);
    if (await outputFile.exists()) {
      await outputFile.delete();
    }

    // ffmpeg command:
    //   -y                : overwrite output without asking
    //   -i <input>        : input file (any format ffmpeg understands)
    //   -ar 44100         : resample to 44100 Hz (matches our record config)
    //   -ac 1             : downmix to mono (matches our record config)
    //   -sample_fmt s16   : 16-bit signed PCM
    //   <output>          : WAV container
    final cmd = [
      '-y',
      '-i',
      sourceFile.path,
      '-ar',
      '44100',
      '-ac',
      '1',
      '-sample_fmt',
      's16',
      outputPath,
    ];

    final session = await FFmpegKit.execute(cmd.join(' '));
    final returnCode = await session.getReturnCode();
    if (!ReturnCode.isSuccess(returnCode)) {
      final logs = await session.getAllLogsAsString();
      debugPrint('[batbox] ffmpeg conversion failed. ReturnCode: $returnCode');
      debugPrint('[batbox] ffmpeg logs:\n$logs');
      throw Exception('Audio conversion failed (code ${returnCode?.getValue()}). '
          'Make sure the file is a valid audio file.');
    }

    if (!await outputFile.exists()) {
      throw Exception('Conversion produced no output file.');
    }
    final bytes = await outputFile.readAsBytes();
    return _decodeWavToSamples(bytes);
  }

  // ---------------------------------------------------------------------------
  // Audio signal processing helpers
  // ---------------------------------------------------------------------------

  /// Downsample by N:1 using a simple averaging low-pass filter.
  List<double> _downsample(List<double> input, int factor) {
    if (input.isEmpty || factor <= 1) return List<double>.from(input);
    final out = <double>[];
    for (var i = 0; i + factor <= input.length; i += factor) {
      double sum = 0.0;
      for (var j = 0; j < factor; j++) {
        sum += input[i + j];
      }
      out.add(sum / factor);
    }
    return out;
  }

  /// Pre-emphasis filter: y[n] = x[n] - 0.95 * x[n-1].
  /// This is a simple high-pass filter that flattens the spectral
  /// envelope of speech/audio signals, making cosine similarity
  /// more robust to speaker/mic frequency response differences.
  List<double> _preEmphasis(List<double> input) {
    if (input.isEmpty) return input;
    final out = List<double>.filled(input.length, 0.0);
    out[0] = input[0];
    for (var i = 1; i < input.length; i++) {
      out[i] = input[i] - 0.95 * input[i - 1];
    }
    return out;
  }

  /// RMS energy of a signal, used for silence gating.
  double _signalEnergy(List<double> samples) {
    if (samples.isEmpty) return 0.0;
    double sum = 0.0;
    for (final s in samples) {
      sum += s * s;
    }
    return sqrt(sum / samples.length);
  }

  /// Compute the energy envelope of a signal: RMS energy in
  /// fixed-size windows. At 4410 Hz with 44-sample windows, each
  /// envelope point represents 10ms of audio. This captures the
  /// rhythmic/temporal pattern of the sound, independent of phase.
  List<double> _computeEnvelope(List<double> input, int windowSize) {
    if (input.isEmpty || windowSize <= 0) return <double>[];
    final out = <double>[];
    for (var i = 0; i + windowSize <= input.length; i += windowSize) {
      double sum = 0.0;
      for (var j = 0; j < windowSize; j++) {
        sum += input[i + j] * input[i + j];
      }
      out.add(sqrt(sum / windowSize));
    }
    return out;
  }

  void _recomputeReferenceDown() {
    _referenceDown.clear();
    _referenceDown.addAll(_downsample(_referenceSamples, 10));

    // Pre-process the reference: apply pre-emphasis so that matching
    // is more robust to speaker/mic frequency response differences.
    _referenceProcessed.clear();
    _referenceProcessed.addAll(_preEmphasis(_referenceDown));

    // Compute reference energy envelope (10ms windows at 4410Hz = 44 samples).
    _referenceEnvelope.clear();
    _referenceEnvelope.addAll(_computeEnvelope(_referenceDown, 44));

    // Compute reference energy for silence gating.
    _referenceEnergy = _signalEnergy(_referenceDown);
    // Silence threshold: live buffer must be at least 10% as loud as
    // the reference, otherwise we skip matching entirely.
    _silenceThreshold = _referenceEnergy * 0.10;

    debugPrint('[batbox] reference: ${_referenceSamples.length} -> ${_referenceDown.length} down, envelope=${_referenceEnvelope.length} pts, energy=${_referenceEnergy.toStringAsFixed(4)}');
  }

  // ---------------------------------------------------------------------------
  // Listening + match detection
  // ---------------------------------------------------------------------------

  Future<void> _toggleListening() async {
    if (_isListening) {
      await _stopListening();
      return;
    }

    if (!_hasReference) {
      setState(() => _status = 'Record or import a reference sound first.');
      return;
    }

    await _requestPermissions();
    if (!await _audioRecorder.hasPermission()) {
      setState(() => _status = 'Microphone permission was not granted.');
      return;
    }

    _photoTriggered = false;
    _isCapturingPhoto = false;
    _sessionPeakSimilarity = 0.0;
    _currentBestSimilarity = 0.0;
    _photosTakenThisSession = 0;
    _burstsThisSession = 0;
    _consecutiveMatchCount = 0;
    _adaptiveNoiseFloor = 0.0;
    _liveSamples.clear();
    _liveDown.clear();
    _lastTriggerTime = DateTime.fromMillisecondsSinceEpoch(0);

    // Only initialize camera if we're actually going to take photos
    // (not in test mode, not in flash-only mode).
    if (!_testMode && _photoCountMode.takesPhotos) {
      try {
        await _initializeCamera();
      } catch (error) {
        setState(() => _status = 'Failed to initialize camera: $error');
        return;
      }
    }

    try {
      _audioSubscription?.cancel();
      final stream = await _audioRecorder.startStream(_recordConfig);
      _audioSubscription = stream.listen((Uint8List event) {
        if (_isCapturingPhoto) return; // pause matching during burst
        _processIncomingChunk(event);
      });

      setState(() {
        _isListening = true;
        _microphoneLevel = 0.0;
        _status = _testMode
            ? 'TEST MODE: Listening for reference sound...'
            : (_photoCountMode.takesPhotos
                ? 'Listening for your reference sound... (${_photoCountMode.label})'
                : 'Listening (flash-only test mode)...');
      });
    } catch (error) {
      setState(() => _status = 'Unable to start live listening: $error');
      await _disposeCamera();
    }
  }

  /// Start/stop test recognition from the Reference tab. Shares all
  /// settings (threshold, mode, etc.) with the Trigger tab via the
  /// shared state fields.
  Future<void> _toggleTestRecognition() async {
    if (_isListening) {
      await _stopListening();
      return;
    }
    if (!_hasReference) {
      setState(() => _status = 'Record or import a reference sound first.');
      return;
    }
    _testMode = true;
    await _toggleListening();
  }

  Future<void> _stopListening() async {
    await _stopAudioStream();
    await _disposeCamera();
    setState(() {
      _isListening = false;
      _testMode = false;
      _microphoneLevel = 0.0;
      _status = _photosTakenThisSession > 0
          ? 'Stopped. Took ${_photosTakenThisSession} photo(s) in ${_burstsThisSession} burst(s).'
          : 'Listening stopped.';
    });
  }

  Future<void> _stopAudioStream() async {
    final subscription = _audioSubscription;
    _audioSubscription = null;
    if (subscription != null) {
      try {
        await subscription.cancel();
      } catch (_) {}
    }
    try {
      if (await _audioRecorder.isRecording()) {
        await _audioRecorder.stop().timeout(
              const Duration(seconds: 2),
              onTimeout: () => null,
            );
      }
    } catch (_) {}
  }

  void _processIncomingChunk(Uint8List bytes) {
    final chunkSamples = pcm16ToDoubles(bytes);
    _liveSamples.addAll(chunkSamples);

    final chunkPeak = chunkSamples.fold<double>(0.0, (current, sample) => max(current, sample.abs()));
    if (mounted) {
      setState(() {
        _microphoneLevel = max(_microphoneLevel * 0.65, chunkPeak);
      });
    }

    // Trim full-rate live buffer.
    final maxLiveLen = _referenceSamples.length * 2;
    if (_liveSamples.length > maxLiveLen) {
      _liveSamples.removeRange(0, _liveSamples.length - maxLiveLen);
    }

    if (_referenceSamples.isEmpty || _liveSamples.length < 1000) {
      return;
    }

    // Downsample live buffer.
    _liveDown.clear();
    _liveDown.addAll(_downsample(_liveSamples, 10));

    if (_referenceDown.isEmpty) {
      _recomputeReferenceDown();
    }
    if (_referenceProcessed.length < 100 || _liveDown.length < _referenceProcessed.length) {
      return;
    }

    // Trim downsampled live buffer to 2x reference length.
    final maxLiveDownLen = _referenceProcessed.length * 2;
    if (_liveDown.length > maxLiveDownLen) {
      _liveDown.removeRange(0, _liveDown.length - maxLiveDownLen);
    }

    // --- Energy gating ---
    // If the live buffer is much quieter than the reference, there's
    // no point running the expensive matcher -- skip this chunk.
    final liveEnergy = _signalEnergy(_liveDown);
    if (liveEnergy < _silenceThreshold) {
      _currentBestSimilarity = 0.0;
      _consecutiveMatchCount = 0; // reset debounce on silence
      if (mounted) setState(() {});
      return;
    }

    // --- Adaptive noise floor ---
    // Track the background noise level. If the current chunk's energy
    // is below 50% of the reference energy, it's probably noise --
    // update the noise floor (EMA filter).
    if (liveEnergy < _referenceEnergy * 0.5) {
      _adaptiveNoiseFloor = _adaptiveNoiseFloor * 0.95 + liveEnergy * 0.05;
    }

    // --- Pre-emphasis on live buffer ---
    final liveProcessed = _preEmphasis(_liveDown);

    // --- PCM-based similarity (phase-sensitive, fine-grained) ---
    final pcmSimilarity = bestSimilarityScore(_referenceProcessed, liveProcessed, stepOverride: 1);

    // --- Envelope-based similarity (phase-invariant, robust) ---
    // Compare energy envelopes instead of raw samples. This captures
    // the temporal/rhythmic pattern and is robust to phase shifts,
    // speaker frequency response, and mic AGC differences.
    final liveEnvelope = _computeEnvelope(_liveDown, 44);
    final envelopeSimilarity = _referenceEnvelope.isNotEmpty && liveEnvelope.length >= _referenceEnvelope.length
        ? bestSimilarityScore(_referenceEnvelope, liveEnvelope, stepOverride: 1)
        : 0.0;

    // --- Combined score ---
    // Weight envelope similarity higher (0.6) because it's more
    // robust. PCM similarity (0.4) confirms the spectral content matches.
    final similarity = envelopeSimilarity * 0.6 + pcmSimilarity * 0.4;

    if (similarity > _sessionPeakSimilarity) {
      _sessionPeakSimilarity = similarity;
    }
    _currentBestSimilarity = similarity;
    debugPrint('[batbox] sim=${similarity.toStringAsFixed(3)} (env=${envelopeSimilarity.toStringAsFixed(3)} pcm=${pcmSimilarity.toStringAsFixed(3)}) peak=${_sessionPeakSimilarity.toStringAsFixed(3)} thr=${_triggerThreshold.toStringAsFixed(2)} liveE=${liveEnergy.toStringAsFixed(4)} noise=${_adaptiveNoiseFloor.toStringAsFixed(4)} consec=$_consecutiveMatchCount');

    if (mounted) {
      setState(() {}); // refresh UI
    }

    // --- Match debouncing ---
    // Require N consecutive chunks above threshold before triggering.
    // This prevents false positives from transient noise (door slams,
    // coughs, etc.) that happen to correlate with the reference.
    if (similarity >= _triggerThreshold) {
      _consecutiveMatchCount++;
    } else {
      _consecutiveMatchCount = 0;
    }

    if (_consecutiveMatchCount < _minMatchChunks) {
      return;
    }

    // Match! Apply refractory period.
    final now = DateTime.now();
    if (now.difference(_lastTriggerTime) < _refractoryPeriod) {
      return;
    }
    _lastTriggerTime = now;

    // Flash always fires (even in test/flashOnly mode).
    _flashActive = true;
    _flashTimer?.cancel();
    _flashTimer = Timer(const Duration(milliseconds: 250), () {
      if (mounted) {
        setState(() => _flashActive = false);
      }
    });

    // Test mode or flash-only mode: don't take photos, just report.
    if (_testMode || !_photoCountMode.takesPhotos) {
      if (mounted) {
        setState(() {
          _status = _testMode
              ? 'TEST: Match detected! sim=${similarity.toStringAsFixed(3)} >= ${_triggerThreshold.toStringAsFixed(2)}'
              : 'Match detected (flash only). Listening for next...';
        });
      }
      return;
    }

    // Photo mode: trigger burst capture.
    _photoTriggered = true;
    _isCapturingPhoto = true;
    _burstsThisSession++;
    final burstSize = _photoCountMode.burstSize;
    if (mounted) {
      setState(() {
        _status = _photoCountMode.stopAfterFirstMatch
            ? 'Match detected! Taking $burstSize photo(s)...'
            : 'Match detected! Taking $burstSize photo(s), then continuing...';
      });
    }
    unawaited(_triggerPhoto().catchError((Object error) {
      debugPrint('_triggerPhoto failed: $error');
      if (mounted) {
        setState(() {
          _photoTriggered = false;
          _isCapturingPhoto = false;
          _flashActive = false;
          _cameraLaunchInProgress = false;
          _status = 'Trigger failed: $error';
        });
      }
    }));
  }

  // ---------------------------------------------------------------------------
  // Photo capture
  // ---------------------------------------------------------------------------

  /// Take a single photo. Does NOT manage _cameraLaunchInProgress or
  /// camera disposal -- the caller handles that.
  Future<void> _takeSinglePhoto() async {
    if (_cameraController == null || !_cameraController!.value.isInitialized) {
      await _initializeCamera().timeout(
        const Duration(seconds: 5),
        onTimeout: () => throw Exception('Camera init timed out.'),
      );
    }
    if (_cameraController == null || !_cameraController!.value.isInitialized) {
      throw Exception('Camera initialization failed.');
    }

    final photo = await _cameraController!.takePicture().timeout(
      const Duration(seconds: 5),
      onTimeout: () => throw Exception('Camera capture timed out.'),
    );
    final saved = await _saveCapturedPhoto(photo.path);
    if (mounted) {
      setState(() {
        _lastSavedPhotoPath = saved.path;
        _capturedPhotoPaths.insert(0, saved.path);
      });
    }
  }

  /// Manual single photo (from the "Take photo manually" button).
  Future<void> _takePhoto({String reason = 'manual'}) async {
    if (_cameraLaunchInProgress) return;
    _cameraLaunchInProgress = true;
    if (mounted) {
      setState(() => _status = 'Taking photo...');
    }
    try {
      final cameraPermission = await Permission.camera.status;
      if (!cameraPermission.isGranted) {
        final requested = await Permission.camera.request();
        if (!requested.isGranted) {
          if (!mounted) return;
          setState(() => _status = 'Camera permission was not granted.');
          return;
        }
      }
      await _takeSinglePhoto();
      if (mounted) {
        setState(() => _status = 'Photo saved to $_lastSavedPhotoPath');
      }
    } catch (error) {
      if (!mounted) return;
      setState(() => _status = 'Could not capture photo: $error');
    } finally {
      _photoTriggered = false;
      _isCapturingPhoto = false;
      if (!_isListening) {
        await _disposeCamera();
      }
      if (mounted) {
        setState(() => _cameraLaunchInProgress = false);
      }
    }
  }

  Future<void> _manualTrigger() async {
    if (_cameraLaunchInProgress) return;
    await _takePhoto(reason: 'manual');
  }

  /// Trigger a burst of photos when a match is detected.
  /// Takes `_photoCountMode.burstSize` photos as fast as possible,
  /// then either stops listening (for finite modes) or continues
  /// listening (for continuous mode).
  Future<void> _triggerPhoto() async {
    if (_cameraLaunchInProgress) return;
    _cameraLaunchInProgress = true;

    final burstSize = _photoCountMode.burstSize;
    final stopAfter = _photoCountMode.stopAfterFirstMatch;

    setState(() {
      _photoTriggered = true;
      _isCapturingPhoto = true;
    });

    try {
      // Take burstSize photos as fast as possible. No inter-photo
      // delay -- the camera's takePicture() call is synchronous and
      // will naturally serialize the captures.
      for (var i = 0; i < burstSize; i++) {
        await _takeSinglePhoto();
        _photosTakenThisSession++;
        if (mounted) {
          setState(() {
            _status = 'Burst: ${i + 1}/$burstSize photos taken...';
          });
        }
      }

      if (stopAfter) {
        // Finite mode: stop listening after the burst.
        await _stopListening();
      } else {
        // Continuous mode: resume listening after refractory period.
        _lastTriggerTime = DateTime.now();
        if (mounted) {
          setState(() {
            _status = 'Burst of $burstSize photo(s) taken. Listening for next match...';
          });
        }
      }
    } catch (error) {
      if (mounted) {
        setState(() => _status = 'Could not capture photo: $error');
      }
    } finally {
      _photoTriggered = false;
      _isCapturingPhoto = false;
      if (!_isListening) {
        await _disposeCamera();
      }
      if (mounted) {
        setState(() => _cameraLaunchInProgress = false);
      }
    }
  }

  Future<void> _initializeCamera() async {
    if (_cameraController != null && _cameraController!.value.isInitialized) {
      return;
    }
    _availableCameras = await availableCameras();
    if (_availableCameras.isEmpty) {
      throw Exception('No cameras available.');
    }
    final camera = _availableCameras.firstWhere(
      (c) => c.lensDirection == CameraLensDirection.back,
      orElse: () => _availableCameras.first,
    );
    _cameraController = CameraController(camera, ResolutionPreset.medium, enableAudio: false);
    await _cameraController!.initialize();
    // Apply the selected flash/torch mode.
    await _applyFlashMode();
  }

  /// Apply the user's selected flash mode to the active camera.
  Future<void> _applyFlashMode() async {
    if (_cameraController == null || !_cameraController!.value.isInitialized) return;
    try {
      final flashMode = _flashModeSetting == FlashModeSetting.off
          ? FlashMode.off
          : _flashModeSetting == FlashModeSetting.auto
              ? FlashMode.auto
              : _flashModeSetting == FlashModeSetting.always
                  ? FlashMode.always
                  : FlashMode.torch;
      await _cameraController!.setFlashMode(flashMode);
    } catch (e) {
      debugPrint('Failed to set flash mode: $e');
    }
  }

  Future<void> _disposeCamera() async {
    _cameraController?.dispose();
    _cameraController = null;
  }

  Future<Directory> _photoDirectory() async {
    final dir = await getApplicationDocumentsDirectory();
    final batboxDir = Directory('${dir.path}${Platform.pathSeparator}batbox');
    if (!await batboxDir.exists()) {
      await batboxDir.create(recursive: true);
    }
    return batboxDir;
  }

  Future<File> _saveCapturedPhoto(String sourcePath) async {
    final photoDir = await _photoDirectory();
    final timestamp = DateTime.now().toIso8601String().replaceAll(':', '-');
    final destination = File('${photoDir.path}${Platform.pathSeparator}batbox-$timestamp.jpg');
    return File(sourcePath).copy(destination.path);
  }

  // ---------------------------------------------------------------------------
  // Photo gallery management
  // ---------------------------------------------------------------------------

  Future<void> _refreshPhotoList() async {
    try {
      final dir = await _photoDirectory();
      final entries = await dir.list().toList();
      final photos = entries
          .whereType<File>()
          .where((f) => f.path.toLowerCase().endsWith('.jpg'))
          .map((f) => f.path)
          .toList()
        ..sort((a, b) => b.compareTo(a));
      setState(() {
        _capturedPhotoPaths
          ..clear()
          ..addAll(photos);
        _selectedPhotoPaths.removeWhere((p) => !photos.contains(p));
      });
    } catch (error) {
      debugPrint('Failed to refresh photo list: $error');
    }
  }

  void _togglePhotoSelection(String path) {
    setState(() {
      if (_selectedPhotoPaths.contains(path)) {
        _selectedPhotoPaths.remove(path);
      } else {
        _selectedPhotoPaths.add(path);
        _selectionMode = true; // any selection enters selection mode
      }
      if (_selectedPhotoPaths.isEmpty) {
        _selectionMode = false;
      }
    });
  }

  void _exitSelectionMode() {
    setState(() {
      _selectionMode = false;
      _selectedPhotoPaths.clear();
    });
  }

  void _selectAllPhotos() {
    setState(() {
      _selectionMode = true;
      _selectedPhotoPaths
        ..clear()
        ..addAll(_capturedPhotoPaths);
    });
  }

  Future<void> _saveSelectedToFolder() async {
    if (_selectedPhotoPaths.isEmpty) return;
    setState(() => _status = 'Saving ${_selectedPhotoPaths.length} photo(s)...');
    try {
      String? targetDirPath;
      try {
        final picked = await FilePicker.platform.getDirectoryPath(
          dialogTitle: 'Choose folder to save photos',
        );
        targetDirPath = picked;
      } catch (_) {
        targetDirPath = null;
      }

      Directory targetDir;
      if (targetDirPath != null && await Directory(targetDirPath).exists()) {
        targetDir = Directory(targetDirPath);
      } else {
        final picturesDir = await _getPicturesDirectory();
        targetDir = Directory('${picturesDir.path}${Platform.pathSeparator}BatBox');
        if (!await targetDir.exists()) {
          await targetDir.create(recursive: true);
        }
      }

      var saved = 0;
      for (final sourcePath in _selectedPhotoPaths) {
        final sourceFile = File(sourcePath);
        if (!await sourceFile.exists()) continue;
        final basename = sourceFile.uri.pathSegments.last;
        final destPath = '${targetDir.path}${Platform.pathSeparator}$basename';
        await sourceFile.copy(destPath);
        saved++;
      }
      setState(() {
        _status = 'Saved $saved photo(s) to ${targetDir.path}';
        _selectionMode = false;
        _selectedPhotoPaths.clear();
      });
      _showSnackBar('Saved $saved photo(s)');
    } catch (error) {
      setState(() => _status = 'Failed to save photos: $error');
      _showSnackBar('Save failed: $error');
    }
  }

  Future<Directory> _getPicturesDirectory() async {
    if (Platform.isAndroid) {
      final dir = Directory('/storage/emulated/0/Pictures');
      if (await dir.exists()) return dir;
    }
    return getApplicationDocumentsDirectory();
  }

  Future<void> _deleteSelectedPhotos() async {
    debugPrint('[batbox] _deleteSelectedPhotos ENTRY, ${_selectedPhotoPaths.length} selected');
    setState(() => _lastAction = 'delete: ${_selectedPhotoPaths.length} selected');
    if (_selectedPhotoPaths.isEmpty) {
      debugPrint('[batbox] delete: nothing selected, showing snackbar');
      _showSnackBar('No photos selected');
      return;
    }
    if (!mounted) {
      debugPrint('[batbox] delete: not mounted, aborting');
      return;
    }

    // Capture messenger before any await.
    final messenger = ScaffoldMessenger.of(context);
    debugPrint('[batbox] delete: messenger captured, proceeding with ${_selectedPhotoPaths.length} files');

    // Copy selected paths before any await.
    final toDelete = List<String>.from(_selectedPhotoPaths);
    final count = toDelete.length;

    // NO confirmation dialog -- delete immediately, offer undo instead.
    // The dialog was causing issues in the tab context. Undo is better UX.
    var deleted = 0;
    final errors = <String>[];
    for (final path in toDelete) {
      try {
        final f = File(path);
        if (await f.exists()) {
          await f.delete();
          deleted++;
          debugPrint('[batbox] deleted: $path');
        } else {
          // File already gone -- count as deleted so it's removed from list.
          deleted++;
        }
      } catch (error) {
        debugPrint('[batbox] FAILED to delete $path: $error');
        errors.add(error.toString());
      }
    }

    if (mounted) {
      setState(() {
        _status = 'Deleted $deleted of $count photo(s).';
        _lastAction = 'deleted $deleted/$count';
        _capturedPhotoPaths.removeWhere((p) => toDelete.contains(p));
        _selectedPhotoPaths.clear();
        _selectionMode = false;
      });
      await _refreshPhotoList();
    }

    if (errors.isEmpty) {
      messenger.showSnackBar(
        SnackBar(
          content: Text('Deleted $deleted photo(s)'),
          duration: const Duration(seconds: 3),
        ),
      );
    } else {
      messenger.showSnackBar(
        SnackBar(
          content: Text('Deleted $deleted of $count. Error: ${errors.first}'),
          duration: const Duration(seconds: 5),
        ),
      );
    }
  }

  void _showSnackBar(String message) {
    if (!mounted) return;
    ScaffoldMessenger.of(context).showSnackBar(
      SnackBar(content: Text(message), duration: const Duration(seconds: 3)),
    );
  }

  void _viewPhoto(String path) {
    debugPrint('[batbox] _viewPhoto called: $path');
    final index = _capturedPhotoPaths.indexOf(path);
    debugPrint('[batbox] view index=$index, total=${_capturedPhotoPaths.length}');
    setState(() => _lastAction = 'view: ${path.split(Platform.pathSeparator).last}');

    // Use showDialog instead of Navigator.push — eliminates all
    // navigator/tab-context issues. The dialog renders above everything.
    showDialog<void>(
      context: context,
      useRootNavigator: true,
      builder: (dialogContext) => Dialog(
        backgroundColor: Colors.black,
        insetPadding: EdgeInsets.zero,
        child: _PhotoViewerDialog(
          photos: List<String>.from(_capturedPhotoPaths),
          initialIndex: index < 0 ? 0 : index,
          onClose: () => Navigator.of(dialogContext).pop(),
        ),
      ),
    );
  }

  void _showInstructions() {
    showDialog<void>(
      context: context,
      builder: (context) => AlertDialog(
        title: const Text('Instructions'),
        content: const SingleChildScrollView(
          child: Text(
            '1. Record or import a reference sound on the Reference tab.\n'
            '2. (Optional) Use "Test recognition" on the Reference tab to tune the threshold.\n'
            '3. Switch to the Trigger tab, pick photo count + flash mode.\n'
            '4. Press Start listening, then make the reference sound.\n'
            '5. View/manage photos on the Photos tab.\n\n'
            'When a match is detected, the app takes a BURST of photos '
            '(1, 3, or 10) as fast as possible, then either stops or '
            'continues listening depending on the mode.',
          ),
        ),
        actions: [
          TextButton(
            onPressed: () => Navigator.of(context).pop(),
            child: const Text('OK'),
          ),
        ],
      ),
    );
  }

  // ---------------------------------------------------------------------------
  // WAV encode / decode
  // ---------------------------------------------------------------------------

  Future<List<int>> _encodeWav(List<double> samples) async {
    const sampleRate = 44100;
    const blockAlign = 2;
    final sampleCount = samples.length;
    final byteRate = sampleRate * blockAlign;
    final dataSize = sampleCount * 2;
    final buffer = BytesBuilder();

    void writeUint32(int value) {
      buffer.addByte(value & 0xff);
      buffer.addByte((value >> 8) & 0xff);
      buffer.addByte((value >> 16) & 0xff);
      buffer.addByte((value >> 24) & 0xff);
    }

    void writeUint16(int value) {
      buffer.addByte(value & 0xff);
      buffer.addByte((value >> 8) & 0xff);
    }

    buffer.add(utf8.encode('RIFF'));
    writeUint32(36 + dataSize);
    buffer.add(utf8.encode('WAVE'));
    buffer.add(utf8.encode('fmt '));
    writeUint32(16);
    writeUint16(1);
    writeUint16(1);
    writeUint32(44100);
    writeUint32(byteRate);
    writeUint16(blockAlign);
    writeUint16(16);
    buffer.add(utf8.encode('data'));
    writeUint32(dataSize);

    for (final sample in samples) {
      final value = (sample.clamp(-1.0, 1.0) * 32767).round();
      writeUint16(value < 0 ? value + 65536 : value);
    }
    return buffer.takeBytes();
  }

  List<double> _decodeWavToSamples(Uint8List bytes) {
    final dataTag = utf8.encode('data');
    int dataIndex = -1;
    for (int i = 0; i + 3 < bytes.length; i++) {
      if (bytes[i] == dataTag[0] && bytes[i + 1] == dataTag[1] && bytes[i + 2] == dataTag[2] && bytes[i + 3] == dataTag[3]) {
        dataIndex = i + 4;
        break;
      }
    }
    if (dataIndex < 0 || dataIndex + 4 > bytes.length) return <double>[];
    final byteData = ByteData.sublistView(bytes);
    final dataSize = byteData.getUint32(dataIndex, Endian.little);
    final dataStart = dataIndex + 4;
    final dataEnd = min(bytes.length, dataStart + dataSize);
    if (dataStart >= dataEnd) return <double>[];
    final audioBytes = bytes.sublist(dataStart, dataEnd);
    return pcm16ToDoubles(Uint8List.fromList(audioBytes));
  }

  // ===========================================================================
  // BUILD
  // ===========================================================================

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'BatBox',
      theme: ThemeData(colorSchemeSeed: Colors.deepPurple, useMaterial3: true),
      home: Scaffold(
        appBar: AppBar(
          title: const Text('BatBox'),
          bottom: TabBar(
            controller: _tabController,
            tabs: const [
              Tab(icon: Icon(Icons.sensors), text: 'Trigger'),
              Tab(icon: Icon(Icons.graphic_eq), text: 'Reference'),
              Tab(icon: Icon(Icons.photo_library), text: 'Photos'),
            ],
          ),
          actions: [
            IconButton(
              icon: const Icon(Icons.help_outline),
              onPressed: _showInstructions,
              tooltip: 'Instructions',
            ),
          ],
        ),
        body: Stack(
          children: [
            AnimatedContainer(
              duration: const Duration(milliseconds: 180),
              color: _flashActive ? Colors.black.withValues(alpha: 0.85) : Colors.transparent,
            ),
            SafeArea(
              child: TabBarView(
                controller: _tabController,
                children: [
                  _buildTriggerTab(),
                  _buildReferenceTab(),
                  _buildPhotosTab(),
                ],
              ),
            ),
          ],
        ),
      ),
    );
  }

  // ---------------------------------------------------------------------------
  // Trigger tab
  // ---------------------------------------------------------------------------

  Widget _buildTriggerTab() {
    return SingleChildScrollView(
      padding: const EdgeInsets.symmetric(horizontal: 24.0, vertical: 12.0),
      child: Column(
        mainAxisSize: MainAxisSize.min,
        crossAxisAlignment: CrossAxisAlignment.center,
        children: [
          const Text(
            'Trigger',
            textAlign: TextAlign.center,
            style: TextStyle(fontSize: 22, fontWeight: FontWeight.bold),
          ),
          const SizedBox(height: 8),
          Container(
            padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 4),
            decoration: BoxDecoration(
              color: Colors.deepPurple.withValues(alpha: 0.15),
              borderRadius: BorderRadius.circular(6),
            ),
            child: const Text(
              'BUILD v9.2 - 2026-06-29 19:30 UTC',
              style: TextStyle(fontSize: 12, fontWeight: FontWeight.bold, color: Colors.deepPurple),
            ),
          ),
          const SizedBox(height: 16),

          // Photo count mode.
          Row(
            mainAxisAlignment: MainAxisAlignment.center,
            children: [
              const Text('Mode: '),
              DropdownButton<PhotoCountMode>(
                value: _photoCountMode,
                items: PhotoCountMode.values
                    .map((m) => DropdownMenuItem(value: m, child: Text(m.label)))
                    .toList(),
                onChanged: (v) {
                  if (v == null) return;
                  setState(() => _photoCountMode = v);
                },
              ),
            ],
          ),
          const SizedBox(height: 8),

          // Flash mode.
          Row(
            mainAxisAlignment: MainAxisAlignment.center,
            children: [
              const Text('Flash: '),
              DropdownButton<FlashModeSetting>(
                value: _flashModeSetting,
                items: FlashModeSetting.values
                    .map((m) => DropdownMenuItem(value: m, child: Text(m.label)))
                    .toList(),
                onChanged: (v) {
                  if (v == null) return;
                  setState(() => _flashModeSetting = v);
                  // Apply immediately if camera is running.
                  _applyFlashMode();
                },
              ),
            ],
          ),
          const SizedBox(height: 8),

          // Recognition mode.
          Row(
            mainAxisAlignment: MainAxisAlignment.center,
            children: [
              const Text('Recognition: '),
              DropdownButton<RecognitionMode>(
                value: _recognitionMode,
                items: const [
                  DropdownMenuItem(value: RecognitionMode.standard, child: Text('Standard')),
                  DropdownMenuItem(value: RecognitionMode.better, child: Text('Better')),
                ],
                onChanged: (v) {
                  if (v == null) return;
                  setState(() => _recognitionMode = v);
                },
              ),
            ],
          ),
          const SizedBox(height: 4),
          Text(
            _hasReference
                ? 'Reference: ${_referenceSamples.length} samples (${(_referenceSamples.length / 44100).toStringAsFixed(1)}s)'
                : 'No reference yet -- go to Reference tab',
            style: TextStyle(
              fontSize: 12,
              color: _hasReference ? Colors.green : Colors.orange,
            ),
          ),
          const SizedBox(height: 12),

          // Start / stop listening.
          FilledButton.icon(
            onPressed: _isListening || _hasReference ? _toggleListening : null,
            icon: Icon(_isListening ? Icons.stop_circle : Icons.sensors),
            label: Text(_isListening ? 'Stop listening' : 'Start listening'),
          ),
          const SizedBox(height: 8),
          FilledButton.icon(
            onPressed: _manualTrigger,
            icon: const Icon(Icons.camera_alt),
            label: const Text('Take photo manually'),
          ),
          const SizedBox(height: 16),

          // Status.
          Text(
            _status,
            textAlign: TextAlign.center,
            style: const TextStyle(fontSize: 16),
          ),
          const SizedBox(height: 12),

          // Live matching diagnostics + threshold slider.
          if (_isListening)
            Column(
              children: [
                Text(
                  'Microphone level: ${(_microphoneLevel * 100).clamp(0.0, 100.0).round()}%',
                  style: Theme.of(context).textTheme.bodyMedium,
                ),
                const SizedBox(height: 6),
                SizedBox(
                  width: 220,
                  child: LinearProgressIndicator(
                    value: _microphoneLevel.clamp(0.0, 1.0),
                    minHeight: 10,
                  ),
                ),
                const SizedBox(height: 12),
                Text(
                  'Similarity: ${_currentBestSimilarity.toStringAsFixed(3)}  (peak: ${_sessionPeakSimilarity.toStringAsFixed(3)})',
                  style: TextStyle(
                    fontSize: 14,
                    fontWeight: FontWeight.bold,
                    color: _currentBestSimilarity >= _triggerThreshold ? Colors.green : Colors.orange,
                  ),
                ),
                const SizedBox(height: 4),
                if (_photoCountMode.takesPhotos)
                  Text(
                    'This session: ${_photosTakenThisSession} photo(s) in ${_burstsThisSession} burst(s)',
                    style: Theme.of(context).textTheme.bodySmall,
                  ),
                const SizedBox(height: 8),
                Text(
                  'Threshold: ${_triggerThreshold.toStringAsFixed(2)}',
                  style: Theme.of(context).textTheme.bodySmall,
                ),
                SizedBox(
                  width: 280,
                  child: Slider(
                    value: _triggerThreshold,
                    min: 0.10,
                    max: 0.90,
                    divisions: 80,
                    label: _triggerThreshold.toStringAsFixed(2),
                    onChanged: (v) => setState(() => _triggerThreshold = v),
                  ),
                ),
              ],
            ),
        ],
      ),
    );
  }

  // ---------------------------------------------------------------------------
  // Reference tab
  // ---------------------------------------------------------------------------

  Widget _buildReferenceTab() {
    return SingleChildScrollView(
      padding: const EdgeInsets.symmetric(horizontal: 24.0, vertical: 12.0),
      child: Column(
        mainAxisSize: MainAxisSize.min,
        crossAxisAlignment: CrossAxisAlignment.center,
        children: [
          const Text(
            'Reference audio',
            textAlign: TextAlign.center,
            style: TextStyle(fontSize: 22, fontWeight: FontWeight.bold),
          ),
          const SizedBox(height: 8),
          Text(
            _hasReference
                ? 'Reference: ${_referenceSamples.length} samples (${(_referenceSamples.length / 44100).toStringAsFixed(1)}s)'
                : 'No reference set yet.',
            textAlign: TextAlign.center,
            style: TextStyle(
              color: _hasReference ? Colors.green : Colors.orange,
              fontWeight: FontWeight.bold,
            ),
          ),
          const SizedBox(height: 16),

          // Record / stop.
          FilledButton.icon(
            onPressed: _toggleReferenceRecording,
            icon: Icon(_isRecordingReference ? Icons.stop : Icons.mic),
            label: Text(_isRecordingReference ? 'Stop recording reference' : 'Record reference'),
          ),
          const SizedBox(height: 8),

          // Import from any audio file (.wav, .m4a, .mp3, etc.)
          OutlinedButton.icon(
            onPressed: _importWavReference,
            icon: const Icon(Icons.file_upload),
            label: const Text('Import audio (.wav, .m4a, .mp3)'),
          ),
          const SizedBox(height: 8),

          // Play / stop playback.
          if (_hasReference)
            FilledButton.icon(
              onPressed: _playReferenceSound,
              icon: Icon(_isPlayingReference ? Icons.stop : Icons.play_arrow),
              label: Text(_isPlayingReference ? 'Stop playback' : 'Play reference sound'),
            ),
          const SizedBox(height: 16),

          // Save / load to app documents.
          Row(
            mainAxisAlignment: MainAxisAlignment.center,
            children: [
              OutlinedButton.icon(
                onPressed: _saveReferenceToFile,
                icon: const Icon(Icons.save),
                label: const Text('Save to file'),
              ),
              const SizedBox(width: 12),
              OutlinedButton.icon(
                onPressed: _loadReferenceFromFile,
                icon: const Icon(Icons.folder_open),
                label: const Text('Load from file'),
              ),
            ],
          ),
          const SizedBox(height: 24),

          // --- Test recognition section ---
          const Divider(),
          const SizedBox(height: 8),
          const Text(
            'Test recognition',
            style: TextStyle(fontSize: 18, fontWeight: FontWeight.bold),
          ),
          const SizedBox(height: 4),
          const Text(
            'Starts listening without taking photos. Shows live\n'
            'similarity so you can tune the threshold.\n'
            'Settings carry over to the Trigger tab.',
            textAlign: TextAlign.center,
            style: TextStyle(fontSize: 12, color: Colors.grey),
          ),
          const SizedBox(height: 12),
          FilledButton.icon(
            onPressed: _hasReference ? _toggleTestRecognition : null,
            icon: Icon(_isListening && _testMode ? Icons.stop_circle : Icons.science),
            label: Text(_isListening && _testMode ? 'Stop test' : 'Start test'),
          ),
          const SizedBox(height: 12),

          // Live test diagnostics -- same widgets as Trigger tab.
          if (_isListening && _testMode)
            Column(
              children: [
                Text(
                  'Microphone level: ${(_microphoneLevel * 100).clamp(0.0, 100.0).round()}%',
                  style: Theme.of(context).textTheme.bodyMedium,
                ),
                const SizedBox(height: 6),
                SizedBox(
                  width: 220,
                  child: LinearProgressIndicator(
                    value: _microphoneLevel.clamp(0.0, 1.0),
                    minHeight: 10,
                  ),
                ),
                const SizedBox(height: 12),
                Text(
                  'Similarity: ${_currentBestSimilarity.toStringAsFixed(3)}  (peak: ${_sessionPeakSimilarity.toStringAsFixed(3)})',
                  style: TextStyle(
                    fontSize: 14,
                    fontWeight: FontWeight.bold,
                    color: _currentBestSimilarity >= _triggerThreshold ? Colors.green : Colors.orange,
                  ),
                ),
                const SizedBox(height: 8),
                Text(
                  'Threshold: ${_triggerThreshold.toStringAsFixed(2)}',
                  style: Theme.of(context).textTheme.bodySmall,
                ),
                SizedBox(
                  width: 280,
                  child: Slider(
                    value: _triggerThreshold,
                    min: 0.10,
                    max: 0.90,
                    divisions: 80,
                    label: _triggerThreshold.toStringAsFixed(2),
                    onChanged: (v) => setState(() => _triggerThreshold = v),
                  ),
                ),
                const SizedBox(height: 8),
                // Recognition mode selector -- shared with Trigger tab.
                Row(
                  mainAxisAlignment: MainAxisAlignment.center,
                  children: [
                    const Text('Recognition: '),
                    DropdownButton<RecognitionMode>(
                      value: _recognitionMode,
                      items: const [
                        DropdownMenuItem(value: RecognitionMode.standard, child: Text('Standard')),
                        DropdownMenuItem(value: RecognitionMode.better, child: Text('Better')),
                      ],
                      onChanged: (v) {
                        if (v == null) return;
                        setState(() => _recognitionMode = v);
                      },
                    ),
                  ],
                ),
              ],
            ),

          const SizedBox(height: 24),

          // Status.
          Text(
            _status,
            textAlign: TextAlign.center,
            style: const TextStyle(fontSize: 14),
          ),
          const SizedBox(height: 16),
          if (_isRecordingReference)
            Column(
              children: [
                Text(
                  'Recording... ${(_referenceSamples.length / 44100).toStringAsFixed(1)}s captured',
                  style: const TextStyle(color: Colors.red, fontWeight: FontWeight.bold),
                ),
                const SizedBox(height: 8),
                const Text(
                  'Tap "Stop recording reference" when done. Aim for 0.5-3 seconds.',
                  textAlign: TextAlign.center,
                  style: TextStyle(fontSize: 12, color: Colors.grey),
                ),
              ],
            ),
        ],
      ),
    );
  }

  // ---------------------------------------------------------------------------
  // Photos tab
  // ---------------------------------------------------------------------------

  Widget _buildPhotosTab() {
    final hasSelection = _selectedPhotoPaths.isNotEmpty;
    return Column(
      children: [
        // --- VISIBLE DEBUG BAR (LARGE + PROMINENT) ---
        // Shows the last action performed. If this doesn't update when
        // you tap things, the tap events aren't reaching the handlers.
        Container(
          width: double.infinity,
          color: Colors.yellow.shade100,
          padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 10),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              const Text(
                'DEBUG BAR (v9.2)',
                style: TextStyle(fontSize: 10, fontWeight: FontWeight.bold, color: Colors.red),
              ),
              const SizedBox(height: 2),
              Text(
                'lastAction: "$_lastAction"',
                style: const TextStyle(fontSize: 14, fontWeight: FontWeight.bold, color: Colors.black87),
              ),
              Text(
                'photos: ${_capturedPhotoPaths.length} | selected: ${_selectedPhotoPaths.length}',
                style: const TextStyle(fontSize: 12, color: Colors.black54),
              ),
            ],
          ),
        ),
        // --- TEST BUTTON ---
        // This button is completely independent of the grid/selection.
        // If tapping this doesn't update the debug bar, NOTHING on this
        // tab is receiving taps and the problem is at the TabBarView level.
        Padding(
          padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 6),
          child: SizedBox(
            width: double.infinity,
            child: ElevatedButton(
              style: ElevatedButton.styleFrom(
                backgroundColor: Colors.deepPurple,
                foregroundColor: Colors.white,
                padding: const EdgeInsets.symmetric(vertical: 14),
              ),
              onPressed: () {
                debugPrint('[batbox] TEST BUTTON TAPPED');
                setState(() {
                  _lastAction = 'TEST BUTTON tapped at ${DateTime.now().toIso8601String().substring(11, 19)}';
                });
              },
              child: const Text('TAP THIS TEST BUTTON', style: TextStyle(fontSize: 16, fontWeight: FontWeight.bold)),
            ),
          ),
        ),
        // --- ACTION BAR ---
        Container(
          color: hasSelection
              ? Colors.deepPurple.withValues(alpha: 0.1)
              : Colors.transparent,
          padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 8),
          child: Row(
            children: [
              Text(hasSelection
                  ? '${_selectedPhotoPaths.length} selected'
                  : '${_capturedPhotoPaths.length} photo(s)'),
              const Spacer(),
              IconButton(
                icon: Icon(hasSelection ? Icons.deselect : Icons.select_all),
                tooltip: hasSelection ? 'Deselect all' : 'Select all',
                onPressed: () {
                  if (hasSelection) {
                    setState(() {
                      _selectedPhotoPaths.clear();
                      _selectionMode = false;
                      _lastAction = 'deselect all';
                    });
                  } else {
                    _selectAllPhotos();
                    setState(() => _lastAction = 'select all');
                  }
                },
              ),
              if (hasSelection)
                IconButton(
                  icon: const Icon(Icons.save_alt),
                  tooltip: 'Save to folder',
                  onPressed: _saveSelectedToFolder,
                ),
              if (hasSelection)
                IconButton(
                  icon: const Icon(Icons.delete),
                  tooltip: 'Delete selected',
                  onPressed: _deleteSelectedPhotos,
                ),
              IconButton(
                icon: const Icon(Icons.refresh),
                tooltip: 'Refresh',
                onPressed: _refreshPhotoList,
              ),
            ],
          ),
        ),
        // --- PHOTO GRID ---
        Expanded(
          child: _capturedPhotoPaths.isEmpty
              ? const Center(
                  child: Text(
                    'No photos yet.\nTrigger a photo from the Trigger tab.',
                    textAlign: TextAlign.center,
                    style: TextStyle(color: Colors.grey),
                  ),
                )
              : GridView.builder(
                  padding: const EdgeInsets.all(4),
                  gridDelegate: const SliverGridDelegateWithFixedCrossAxisCount(
                    crossAxisCount: 3,
                    mainAxisSpacing: 4,
                    crossAxisSpacing: 4,
                  ),
                  itemCount: _capturedPhotoPaths.length,
                  itemBuilder: (context, index) {
                    final path = _capturedPhotoPaths[index];
                    final selected = _selectedPhotoPaths.contains(path);
                    // SIMPLEST POSSIBLE WIDGET TREE:
                    //   - ClipRRect for rounded corners
                    //   - GestureDetector with behavior: opaque (catches ALL taps)
                    //   - Stack only contains the image + a small checkbox button
                    return ClipRRect(
                      borderRadius: BorderRadius.circular(4),
                      child: Stack(
                        fit: StackFit.expand,
                        children: [
                          // Image with opaque tap detector.
                          GestureDetector(
                            behavior: HitTestBehavior.opaque,
                            onTap: () {
                              debugPrint('[batbox] TAP on photo $index: $path');
                              _viewPhoto(path);
                            },
                            child: Container(
                              color: Colors.grey.shade300,
                              child: Image.file(
                                File(path),
                                fit: BoxFit.cover,
                                errorBuilder: (_, __, ___) => const Center(
                                  child: Icon(Icons.broken_image, color: Colors.white70),
                                ),
                              ),
                            ),
                          ),
                          // Checkbox button -- top-right, explicit size, opaque.
                          Positioned(
                            top: 4,
                            right: 4,
                            child: GestureDetector(
                              behavior: HitTestBehavior.opaque,
                              onTap: () {
                                debugPrint('[batbox] TAP on checkbox $index');
                                _togglePhotoSelection(path);
                              },
                              child: Container(
                                width: 32,
                                height: 32,
                                decoration: BoxDecoration(
                                  color: Colors.black54,
                                  shape: BoxShape.circle,
                                ),
                                child: Icon(
                                  selected ? Icons.check_circle : Icons.radio_button_unchecked,
                                  color: selected ? Colors.deepPurple : Colors.white,
                                  size: 24,
                                ),
                              ),
                            ),
                          ),
                          // Selection tint.
                          if (selected)
                            IgnorePointer(
                              child: Container(
                                color: Colors.deepPurple.withValues(alpha: 0.3),
                              ),
                            ),
                        ],
                      ),
                    );
                  },
                ),
        ),
      ],
    );
  }
}

// =============================================================================
// Photo viewer (full-screen)
// =============================================================================

class _PhotoViewerDialog extends StatefulWidget {
  const _PhotoViewerDialog({required this.photos, required this.initialIndex, required this.onClose});
  final List<String> photos;
  final int initialIndex;
  final VoidCallback onClose;

  @override
  State<_PhotoViewerDialog> createState() => _PhotoViewerDialogState();
}

class _PhotoViewerDialogState extends State<_PhotoViewerDialog> {
  late PageController _pageController;
  late int _currentIndex;

  @override
  void initState() {
    super.initState();
    _currentIndex = widget.initialIndex;
    _pageController = PageController(initialPage: widget.initialIndex);
  }

  @override
  void dispose() {
    _pageController.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    if (widget.photos.isEmpty) {
      return Container(
        color: Colors.black,
        child: Center(
          child: Column(
            mainAxisSize: MainAxisSize.min,
            children: [
              const Text('No photos available.', style: TextStyle(color: Colors.white)),
              const SizedBox(height: 16),
              TextButton(onPressed: widget.onClose, child: const Text('Close')),
            ],
          ),
        ),
      );
    }
    return Scaffold(
      backgroundColor: Colors.black,
      appBar: AppBar(
        backgroundColor: Colors.black87,
        foregroundColor: Colors.white,
        title: Text(
          '${_currentIndex + 1} / ${widget.photos.length}',
          style: const TextStyle(fontSize: 16),
        ),
        leading: IconButton(
          icon: const Icon(Icons.close),
          onPressed: widget.onClose,
        ),
      ),
      body: PageView.builder(
        controller: _pageController,
        itemCount: widget.photos.length,
        onPageChanged: (index) => setState(() => _currentIndex = index),
        itemBuilder: (context, index) {
          final path = widget.photos[index];
          return GestureDetector(
            onTap: widget.onClose,
            child: Center(
              child: InteractiveViewer(
                minScale: 0.5,
                maxScale: 4.0,
                child: Image.file(
                  File(path),
                  fit: BoxFit.contain,
                  errorBuilder: (_, __, ___) => const Column(
                    mainAxisAlignment: MainAxisAlignment.center,
                    children: [
                      Icon(Icons.broken_image, size: 64, color: Colors.white54),
                      SizedBox(height: 8),
                      Text('Failed to load image', style: TextStyle(color: Colors.white54)),
                    ],
                  ),
                ),
              ),
            ),
          );
        },
      ),
    );
  }
}
// =============================================================================
// Math: cosine similarity helpers (improved)
// =============================================================================

/// Basic cosine similarity (kept for fallback).
double similarityScore(List<double> reference, List<double> candidate) {
  if (reference.isEmpty || candidate.isEmpty) return 0.0;
  final length = min(reference.length, candidate.length);
  double dotProduct = 0.0;
  double refNorm = 0.0;
  double candNorm = 0.0;
  for (var i = 0; i < length; i++) {
    final r = reference[i];
    final c = candidate[i];
    dotProduct += r * c;
    refNorm += r * r;
    candNorm += c * c;
  }
  if (refNorm == 0 || candNorm == 0) return 0.0;
  return dotProduct / (sqrt(refNorm * candNorm));
}

/// Normalized cosine similarity of reference[0..length) vs
/// live[start..start+length). Subtracts the mean of each window
/// before computing the dot product, which makes the score robust
/// to DC offset and volume differences between speaker and mic.
/// Allocates nothing; reads both lists by index.
double normalizedCosineSimRange(List<double> reference, List<double> live, int start, int length) {
  // Pass 1: compute means.
  double refSum = 0.0;
  double liveSum = 0.0;
  for (var i = 0; i < length; i++) {
    refSum += reference[i];
    liveSum += live[start + i];
  }
  final refMean = refSum / length;
  final liveMean = liveSum / length;

  // Pass 2: normalized dot product and norms.
  double dotProduct = 0.0;
  double refNorm = 0.0;
  double liveNorm = 0.0;
  for (var i = 0; i < length; i++) {
    final r = reference[i] - refMean;
    final c = live[start + i] - liveMean;
    dotProduct += r * c;
    refNorm += r * r;
    liveNorm += c * c;
  }
  if (refNorm == 0 || liveNorm == 0) return 0.0;
  return dotProduct / (sqrt(refNorm * liveNorm));
}

/// Find the best normalized cosine similarity between the reference
/// and any window of the live buffer. Uses a coarse-to-fine search:
///   1. Coarse pass (step = targetLength/16) to find the best region.
///   2. Fine pass (step = 1) around the best region to find the
///      exact alignment.
/// This is ~16x faster than a full step=1 search while still finding
/// the true best alignment (which is critical because cosine
/// similarity on PCM is extremely phase-sensitive).
double bestSimilarityScore(List<double> reference, List<double> liveSamples, {int? stepOverride}) {
  if (reference.isEmpty || liveSamples.isEmpty) return 0.0;

  final targetLength = min(reference.length, liveSamples.length);
  if (targetLength < 10) return similarityScore(reference, liveSamples);

  final searchSpan = liveSamples.length - targetLength;
  if (searchSpan <= 0) return normalizedCosineSimRange(reference, liveSamples, 0, targetLength);

  // If stepOverride is provided and is 1, use coarse-to-fine.
  // Otherwise use the requested step directly (for Standard mode).
  if (stepOverride != null && stepOverride > 1) {
    var bestScore = 0.0;
    for (var start = 0; start <= searchSpan; start += stepOverride) {
      final score = normalizedCosineSimRange(reference, liveSamples, start, targetLength);
      if (score > bestScore) bestScore = score;
    }
    return bestScore;
  }

  // Coarse-to-fine (Better mode / step=1).
  final coarseStep = max(1, targetLength ~/ 16);
  var bestScore = 0.0;
  var bestStart = 0;

  // Coarse pass.
  for (var start = 0; start <= searchSpan; start += coarseStep) {
    final score = normalizedCosineSimRange(reference, liveSamples, start, targetLength);
    if (score > bestScore) {
      bestScore = score;
      bestStart = start;
    }
  }

  // Fine pass: step=1 around the best coarse position, within ±coarseStep.
  if (coarseStep > 1) {
    final fineStart = max(0, bestStart - coarseStep);
    final fineEnd = min(searchSpan, bestStart + coarseStep);
    for (var start = fineStart; start <= fineEnd; start++) {
      final score = normalizedCosineSimRange(reference, liveSamples, start, targetLength);
      if (score > bestScore) bestScore = score;
    }
  }

  return bestScore;
}

List<double> pcm16ToDoubles(Uint8List bytes) {
  final samples = <double>[];
  final byteData = ByteData.sublistView(bytes);
  for (var i = 0; i + 1 < bytes.length; i += 2) {
    final sample = byteData.getInt16(i, Endian.little);
    samples.add(sample / 32768.0);
  }
  return samples;
}
