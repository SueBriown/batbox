import 'dart:async';
import 'dart:convert';
import 'dart:math';
import 'dart:typed_data';
import 'dart:io';
import 'dart:ui' show PlatformDispatcher;

import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:camera/camera.dart';
import 'package:file_picker/file_picker.dart';
import 'package:ffmpeg_kit_flutter_new/ffmpeg_kit.dart';
import 'package:ffmpeg_kit_flutter_new/return_code.dart';
import 'package:just_audio/just_audio.dart';
import 'package:path_provider/path_provider.dart';
import 'package:permission_handler/permission_handler.dart';
import 'package:record/record.dart';
import 'package:share_plus/share_plus.dart';
import 'package:shared_preferences/shared_preferences.dart';

void main() {
  // Catch all unhandled Flutter errors so we never get a white screen.
  FlutterError.onError = (FlutterErrorDetails details) {
    FlutterError.presentError(details);
    debugPrint('[batbox] FLUTTER ERROR: ${details.exception}');
    debugPrint('[batbox] stack: ${details.stack}');
  };
  // Catch all unhandled async errors.
  PlatformDispatcher.instance.onError = (Object error, StackTrace stack) {
    debugPrint('[batbox] ASYNC ERROR: $error');
    debugPrint('[batbox] stack: $stack');
    return true;
  };
  runApp(const BatboxApp());
}

// =============================================================================
// Enums
// =============================================================================

enum RecognitionMode {
  standard('Standard'),
  better('Better');

  const RecognitionMode(this.label);
  final String label;
}

enum PhotoCountMode {
  one('1 photo per match'),
  three('3 photos per match'),
  ten('10 photos per match'),
  continuous('Continuous (1 per match)'),
  flashOnly('Flash only (test)');

  const PhotoCountMode(this.label);
  final String label;
  int get burstSize {
    switch (this) {
      case PhotoCountMode.one: return 1;
      case PhotoCountMode.three: return 3;
      case PhotoCountMode.ten: return 10;
      case PhotoCountMode.continuous: return 1;
      case PhotoCountMode.flashOnly: return 0;
    }
  }
  bool get stopAfterFirstMatch {
    switch (this) {
      case PhotoCountMode.one:
      case PhotoCountMode.three:
      case PhotoCountMode.ten: return true;
      case PhotoCountMode.continuous:
      case PhotoCountMode.flashOnly: return false;
    }
  }
  bool get takesPhotos => this != PhotoCountMode.flashOnly;
}

enum FlashModeSetting {
  off('Off'), auto('Auto'), always('Always flash'), torch('Torch (continuous)');
  const FlashModeSetting(this.label);
  final String label;
}

enum ResolutionSetting {
  low('Low'), medium('Medium'), high('High');
  const ResolutionSetting(this.label);
  final String label;
  ResolutionPreset get preset {
    switch (this) {
      case ResolutionSetting.low: return ResolutionPreset.low;
      case ResolutionSetting.medium: return ResolutionPreset.medium;
      case ResolutionSetting.high: return ResolutionPreset.high;
    }
  }
}

// =============================================================================
// Reference sound data class
// =============================================================================

class ReferenceSound {
  String name;
  String filePath;
  List<double> samples = [];
  List<double> downsampled = [];
  List<double> processed = [];
  List<double> envelope = [];
  double energy = 0.0;
  double silenceThreshold = 0.0;

  ReferenceSound({required this.name, required this.filePath});

  Map<String, dynamic> toJson() => {'name': name, 'filePath': filePath};
  factory ReferenceSound.fromJson(Map<String, dynamic> json) =>
      ReferenceSound(
        name: (json['name'] as String?) ?? 'Unknown',
        filePath: (json['filePath'] as String?) ?? '',
      );
}

// =============================================================================
// Global navigator key (bulletproof navigation)
// =============================================================================

final GlobalKey<NavigatorState> rootNavigatorKey = GlobalKey<NavigatorState>();

// =============================================================================
// App
// =============================================================================

class BatboxApp extends StatefulWidget {
  const BatboxApp({super.key});
  @override
  State<BatboxApp> createState() => _BatboxAppState();
}

class _BatboxAppState extends State<BatboxApp> with TickerProviderStateMixin {
  final AudioRecorder _audioRecorder = AudioRecorder();
  final AudioPlayer _audioPlayer = AudioPlayer();
  StreamSubscription<dynamic>? _audioSubscription;
  List<CameraDescription> _availableCameras = [];
  CameraController? _cameraController;
  Timer? _flashTimer;
  Timer? _autoStopTimer;
  late TabController _tabController;

  SharedPreferences? _prefs;  // nullable to handle init race conditions

  // --- Settings (persisted) ---
  double _triggerThreshold = 0.35;
  RecognitionMode _recognitionMode = RecognitionMode.better;
  PhotoCountMode _photoCountMode = PhotoCountMode.one;
  FlashModeSetting _flashModeSetting = FlashModeSetting.off;
  ResolutionSetting _resolutionSetting = ResolutionSetting.medium;
  int _refractoryPeriodMs = 1500;
  bool _autoStopOnSilence = false;
  int _autoStopTimeoutSec = 30;
  bool _hapticOnMatch = true;

  // --- Settings keys ---
  static const _kThreshold = 'threshold';
  static const _kRecogMode = 'recog_mode';
  static const _kPhotoCount = 'photo_count';
  static const _kFlashMode = 'flash_mode';
  static const _kResolution = 'resolution';
  static const _kRefractory = 'refractory_ms';
  static const _kAutoStop = 'auto_stop';
  static const _kAutoStopTimeout = 'auto_stop_timeout';
  static const _kHaptic = 'haptic';
  static const _kReferenceList = 'reference_list';
  static const _kActiveReference = 'active_reference';

  // --- Reference library ---
  final List<ReferenceSound> _references = [];
  String _activeReferenceName = '';

  // Active reference buffers (computed from the active ReferenceSound)
  final List<double> _referenceSamples = [];
  final List<double> _referenceDown = [];
  final List<double> _referenceProcessed = [];
  final List<double> _referenceEnvelope = [];
  double _referenceEnergy = 0.0;
  double _silenceThreshold = 0.0;

  // --- Live audio buffers ---
  final List<double> _liveSamples = [];
  final List<double> _liveDown = [];
  double _adaptiveNoiseFloor = 0.0;

  // --- Matching state ---
  double _currentBestSimilarity = 0.0;
  double _sessionPeakSimilarity = 0.0;
  int _consecutiveMatchCount = 0;
  static const int _minMatchChunks = 2;
  DateTime _lastTriggerTime = DateTime.fromMillisecondsSinceEpoch(0);
  DateTime _lastLoudAudioTime = DateTime.fromMillisecondsSinceEpoch(0);

  // --- Spectrogram + histogram ---
  final List<List<double>> _spectrogramFrames = []; // last N FFT frames
  static const int _maxSpectrogramFrames = 80;
  final List<double> _similarityHistory = []; // last N similarity scores
  static const int _maxHistoryLen = 30;

  // --- Photo state ---
  final List<String> _allPhotoPaths = [];
  final Map<String, List<String>> _photosBySession = {}; // sessionLabel -> paths
  final Set<String> _selectedPhotoPaths = {};
  bool _selectionMode = false;
  String _currentSessionId = '';

  // --- Recording / listening state ---
  bool _isRecordingReference = false;
  bool _isListening = false;
  bool _testMode = false;
  bool _photoTriggered = false;
  bool _isCapturingPhoto = false;
  bool _isPlayingReference = false;
  bool _flashActive = false;
  bool _cameraLaunchInProgress = false;
  double _microphoneLevel = 0.0;
  String _status = 'Record a short reference sound to begin.';
  String _lastSavedPhotoPath = '';
  int _photosTakenThisSession = 0;
  int _burstsThisSession = 0;

  late StreamSubscription<PlayerState> _playerStateSubscription;

  final RecordConfig _recordConfig = const RecordConfig(
    encoder: AudioEncoder.pcm16bits,
    sampleRate: 44100,
    numChannels: 1,
  );

  // ===========================================================================
  // Lifecycle
  // ===========================================================================

  @override
  void initState() {
    super.initState();
    _tabController = TabController(length: 3, vsync: this);
    _initPrefsAndLoad();
    _playerStateSubscription = _audioPlayer.playerStateStream.listen((state) {
      if (!mounted) return;
      setState(() => _isPlayingReference = state.playing);
      if (state.processingState == ProcessingState.completed) {
        if (mounted) setState(() => _isPlayingReference = false);
      }
    });
  }

  Future<void> _initPrefsAndLoad() async {
    try {
      _prefs = await SharedPreferences.getInstance();
      debugPrint('[batbox] _prefs initialized: ${_prefs != null}');
      _loadSettings();
      await _loadReferenceLibrary();
      await _refreshPhotoSessions();
    } catch (e, stack) {
      debugPrint('[batbox] FATAL during init: $e');
      debugPrint('[batbox] stack: $stack');
      // Don't rethrow -- let the app render, just show error in status
      if (mounted) {
        setState(() => _status = 'Init error: $e');
      }
    }
  }

  @override
  void dispose() {
    _tabController.dispose();
    _audioSubscription?.cancel();
    _autoStopTimer?.cancel();
    _playerStateSubscription.cancel();
    _audioPlayer.dispose();
    try { _audioRecorder.dispose(); } catch (_) {}
    _cameraController?.dispose();
    super.dispose();
  }

  // ===========================================================================
  // Settings persistence
  // ===========================================================================


  void _loadSettings() {
    final p = _prefs;
    if (p == null) {
      debugPrint('[batbox] _loadSettings: _prefs is null, using defaults');
      return;
    }
    try {
      _triggerThreshold = p.getDouble(_kThreshold) ?? 0.35;

      // Bounds-checked enum loading -- prevents RangeError if a stored
      // index is out of range (e.g. after enum reordering or corruption).
      T _loadEnum<T>(String key, List<T> values, T defaultValue) {
        final idx = p.getInt(key);
        if (idx == null || idx < 0 || idx >= values.length) return defaultValue;
        return values[idx];
      }

      _recognitionMode = _loadEnum(_kRecogMode, RecognitionMode.values, RecognitionMode.better);
      _photoCountMode = _loadEnum(_kPhotoCount, PhotoCountMode.values, PhotoCountMode.one);
      _flashModeSetting = _loadEnum(_kFlashMode, FlashModeSetting.values, FlashModeSetting.off);
      _resolutionSetting = _loadEnum(_kResolution, ResolutionSetting.values, ResolutionSetting.medium);
      _refractoryPeriodMs = p.getInt(_kRefractory) ?? 1500;
      _autoStopOnSilence = p.getBool(_kAutoStop) ?? false;
      _autoStopTimeoutSec = p.getInt(_kAutoStopTimeout) ?? 30;
      _hapticOnMatch = p.getBool(_kHaptic) ?? true;
      _activeReferenceName = p.getString(_kActiveReference) ?? '';
    } catch (e) {
      debugPrint('[batbox] _loadSettings failed, using defaults: $e');
    }
  }

  Future<void> _saveSettings() async {
    final p = _prefs;
    if (p == null) {
      debugPrint('[batbox] _saveSettings: _prefs is null, skipping');
      return;
    }
    try {
      await p.setDouble(_kThreshold, _triggerThreshold);
      await p.setInt(_kRecogMode, _recognitionMode.index);
      await p.setInt(_kPhotoCount, _photoCountMode.index);
      await p.setInt(_kFlashMode, _flashModeSetting.index);
      await p.setInt(_kResolution, _resolutionSetting.index);
      await p.setInt(_kRefractory, _refractoryPeriodMs);
      await p.setBool(_kAutoStop, _autoStopOnSilence);
      await p.setInt(_kAutoStopTimeout, _autoStopTimeoutSec);
      await p.setBool(_kHaptic, _hapticOnMatch);
      await p.setString(_kActiveReference, _activeReferenceName);
    } catch (e) {
      debugPrint('[batbox] _saveSettings failed: $e');
    }
  }

  // ===========================================================================
  // Reference library management
  // ===========================================================================

  Future<Directory> _referencesDirectory() async {
    final dir = await getApplicationDocumentsDirectory();
    final refDir = Directory('${dir.path}${Platform.pathSeparator}references');
    if (!await refDir.exists()) await refDir.create(recursive: true);
    return refDir;
  }

  Future<void> _loadReferenceLibrary() async {
    try {
      final p = _prefs;
      if (p == null) { debugPrint('[batbox] _loadReferenceLibrary: _prefs null'); return; }
      final listJson = p.getStringList(_kReferenceList) ?? [];
      _references.clear();
      for (final json in listJson) {
        try {
          final map = jsonDecode(json) as Map<String, dynamic>;
          final ref = ReferenceSound.fromJson(map);
          final file = File(ref.filePath);
          if (await file.exists()) {
            final bytes = await file.readAsBytes();
            ref.samples.addAll(_decodeWavToSamples(bytes));
            _computeReferenceFeatures(ref);
            _references.add(ref);
          }
        } catch (e) {
          debugPrint('Failed to load reference: $e');
        }
      }
      // Select active reference
      if (_activeReferenceName.isNotEmpty) {
        _switchToReference(_activeReferenceName);
      } else if (_references.isNotEmpty) {
        _switchToReference(_references.first.name);
      }
    } catch (e) {
      debugPrint('[batbox] _loadReferenceLibrary failed: $e');
    }
    if (mounted) setState(() {});
  }

  Future<void> _saveReferenceList() async {
    final p = _prefs;
    if (p == null) {
      debugPrint('[batbox] _saveReferenceList: _prefs is null, skipping');
      return;
    }
    try {
      final list = _references.map((r) => jsonEncode(r.toJson())).toList();
      await p.setStringList(_kReferenceList, list);
    } catch (e) {
      debugPrint('[batbox] _saveReferenceList failed: $e');
    }
  }

  void _computeReferenceFeatures(ReferenceSound ref) {
    ref.downsampled.clear();
    ref.downsampled.addAll(_downsample(ref.samples, 10));
    ref.processed.clear();
    ref.processed.addAll(_preEmphasis(ref.downsampled));
    ref.envelope.clear();
    ref.envelope.addAll(_computeEnvelope(ref.downsampled, 44));
    ref.energy = _signalEnergy(ref.downsampled);
    ref.silenceThreshold = ref.energy * 0.10;
  }

  void _switchToReference(String name) {
    final ref = _references.where((r) => r.name == name).firstOrNull;
    if (ref == null) return;
    _activeReferenceName = name;
    _referenceSamples.clear();
    _referenceSamples.addAll(ref.samples);
    _referenceDown.clear();
    _referenceDown.addAll(ref.downsampled);
    _referenceProcessed.clear();
    _referenceProcessed.addAll(ref.processed);
    _referenceEnvelope.clear();
    _referenceEnvelope.addAll(ref.envelope);
    _referenceEnergy = ref.energy;
    _silenceThreshold = ref.silenceThreshold;
    _saveSettings();
    if (mounted) setState(() {});
  }

  Future<void> _addReference(String name, List<double> samples) async {
    debugPrint('[batbox] _addReference: name="$name", samples=${samples.length}');
    try {
      debugPrint('[batbox] step 1: get references directory');
      final dir = await _referencesDirectory();
      debugPrint('[batbox] step 2: sanitize name');
      final safeName = name.replaceAll(RegExp(r'[^a-zA-Z0-9_-]'), '_');
      final filePath = '${dir.path}${Platform.pathSeparator}$safeName.wav';
      debugPrint('[batbox] step 3: create ReferenceSound object, filePath=$filePath');
      final ref = ReferenceSound(name: name, filePath: filePath);
      ref.samples.addAll(samples);
      debugPrint('[batbox] step 4: compute features');
      _computeReferenceFeatures(ref);
      debugPrint('[batbox] step 5: encode WAV');
      final wavBytes = await _encodeWav(ref.samples);
      debugPrint('[batbox] step 6: write WAV file (${wavBytes.length} bytes)');
      final file = File(filePath);
      await file.writeAsBytes(wavBytes);
      debugPrint('[batbox] step 7: add to _references list');
      _references.add(ref);
      debugPrint('[batbox] step 8: save reference list');
      await _saveReferenceList();
      // Copy features to active buffers directly instead of calling
      // _switchToReference (which calls _saveSettings and may fail if
      // _prefs isn't ready).
      _activeReferenceName = name;
      _referenceSamples.clear();
      _referenceSamples.addAll(ref.samples);
      _referenceDown.clear();
      _referenceDown.addAll(ref.downsampled);
      _referenceProcessed.clear();
      _referenceProcessed.addAll(ref.processed);
      _referenceEnvelope.clear();
      _referenceEnvelope.addAll(ref.envelope);
      _referenceEnergy = ref.energy;
      _silenceThreshold = ref.silenceThreshold;
      // Try to persist the active reference name, but don't fail if
      // _prefs isn't initialized yet.
      try {
        final p = _prefs;
        if (p != null) await p.setString(_kActiveReference, name);
      } catch (e) {
        debugPrint('[batbox] could not persist active reference: $e');
      }
      if (mounted) setState(() {});
      debugPrint('[batbox] reference added: $name (${samples.length} samples)');
    } catch (e, stack) {
      debugPrint('[batbox] _addReference FAILED at some step: $e');
      debugPrint('[batbox] stack: $stack');
      rethrow;
    }
  }

  Future<void> _deleteReference(String name) async {
    final ref = _references.where((r) => r.name == name).firstOrNull;
    if (ref == null) return;
    try {
      final file = File(ref.filePath);
      if (await file.exists()) await file.delete();
    } catch (_) {}
    _references.remove(ref);
    await _saveReferenceList();
    if (_activeReferenceName == name) {
      _activeReferenceName = '';
      _referenceSamples.clear();
      _referenceDown.clear();
      _referenceProcessed.clear();
      _referenceEnvelope.clear();
      _referenceEnergy = 0.0;
      _silenceThreshold = 0.0;
      if (_references.isNotEmpty) {
        _switchToReference(_references.first.name);
      }
    }
    if (mounted) setState(() {});
  }

  Future<void> _renameReference(String oldName, String newName) async {
    final ref = _references.where((r) => r.name == oldName).firstOrNull;
    if (ref == null) return;
    ref.name = newName;
    if (_activeReferenceName == oldName) {
      _activeReferenceName = newName;
    }
    await _saveReferenceList();
    await _saveSettings();
    if (mounted) setState(() {});
  }

  bool get _hasReference => _referenceSamples.isNotEmpty;

  // ===========================================================================
  // Permissions
  // ===========================================================================

  Future<void> _requestPermissions() async {
    await Permission.microphone.request();
    await Permission.camera.request();
  }

  // ===========================================================================
  // Reference recording / playback / import
  // ===========================================================================

  Future<void> _toggleReferenceRecording() async {
    if (_isRecordingReference) {
      await _stopAudioStream();
      final samples = List<double>.from(_referenceSamples);
      _referenceSamples.clear();
      setState(() => _isRecordingReference = false);
      if (samples.length > 2000) {
        try {
          // Prompt for name
          final name = await _promptForName('Name this reference');
          if (name != null && name.isNotEmpty) {
            await _addReference(name, samples);
            setState(() => _status = 'Reference "$name" saved.');
            _showSnackBar('Saved "$name"');
          } else {
            // Save as default name
            final defaultName = 'Reference ${_references.length + 1}';
            await _addReference(defaultName, samples);
            setState(() => _status = 'Reference "$defaultName" saved.');
            _showSnackBar('Saved "$defaultName"');
          }
        } catch (e, stack) {
          debugPrint('[batbox] save reference failed: $e');
          debugPrint('[batbox] stack: $stack');
          setState(() => _status = 'Save failed: $e');
          _showSnackBar('Save failed: $e');
        }
      } else {
        setState(() => _status = 'Reference too short. Try again.');
        _showSnackBar('Reference too short');
      }
      return;
    }

    await _requestPermissions();
    if (!await _audioRecorder.hasPermission()) {
      setState(() => _status = 'Microphone permission was not granted.');
      return;
    }

    _referenceSamples.clear();
    _liveSamples.clear();
    _microphoneLevel = 0.0;

    try {
      _audioSubscription?.cancel();
      final stream = await _audioRecorder.startStream(_recordConfig);
      _audioSubscription = stream.listen((Uint8List event) {
        if (!_isRecordingReference) return;
        _referenceSamples.addAll(pcm16ToDoubles(event));
      });
      setState(() {
        _isRecordingReference = true;
        _status = 'Recording reference sound...';
      });
    } catch (error) {
      setState(() => _status = 'Unable to start recording: $error');
    }
  }

  Future<String?> _promptForName(String title) async {
    final controller = TextEditingController();
    // Use rootNavigatorKey.currentContext instead of this.context.
    // After an async gap (e.g. FilePicker.await), the State's context
    // can become stale and Navigator.of(context) returns null, throwing
    // "Null check operator used on a null value". The root navigator
    // key's context is always valid as long as the app is running.
    final ctx = rootNavigatorKey.currentContext ?? context;
    return showDialog<String>(
      context: ctx,
      useRootNavigator: true,
      builder: (dialogCtx) => AlertDialog(
        title: Text(title),
        content: TextField(
          controller: controller,
          decoration: const InputDecoration(hintText: 'Enter name'),
          autofocus: true,
          onSubmitted: (v) => Navigator.pop(dialogCtx, v),
        ),
        actions: [
          TextButton(onPressed: () => Navigator.pop(dialogCtx, null), child: const Text('Cancel')),
          FilledButton(onPressed: () => Navigator.pop(dialogCtx, controller.text), child: const Text('OK')),
        ],
      ),
    );
  }

  Future<void> _playReferenceSound() async {
    if (!_hasReference) {
      setState(() => _status = 'No reference to play.');
      return;
    }
    if (_isPlayingReference) {
      await _audioPlayer.stop();
      setState(() => _isPlayingReference = false);
      return;
    }
    try {
      final dir = await getTemporaryDirectory();
      final path = '${dir.path}/reference_play.wav';
      await File(path).writeAsBytes(await _encodeWav(_referenceSamples));
      await _audioPlayer.setFilePath(path);
      await _audioPlayer.play();
      setState(() => _isPlayingReference = true);
    } catch (e) {
      setState(() => _status = 'Could not play: $e');
    }
  }

  /// Save the active reference as a .wav file to the app's documents dir.
  /// The user can then access it via a file manager or 'Load from file'.
  Future<void> _saveReferenceToFile() async {
    if (!_hasReference) {
      setState(() => _status = 'No reference to save.');
      return;
    }
    try {
      final dir = await getApplicationDocumentsDirectory();
      final safeName = _activeReferenceName.replaceAll(RegExp(r'[^a-zA-Z0-9_-]'), '_');
      final path = '${dir.path}${Platform.pathSeparator}$safeName.wav';
      final file = File(path);
      await file.writeAsBytes(await _encodeWav(_referenceSamples));
      setState(() => _status = 'Saved to $path');
      _showSnackBar('Reference saved to $path');
    } catch (e) {
      setState(() => _status = 'Save failed: $e');
      _showSnackBar('Save failed: $e');
    }
  }

  /// Load a .wav file from the app's documents dir as a new reference.
  Future<void> _loadReferenceFromFile() async {
    try {
      // Use FileType.any instead of FileType.custom -- on some Android
      // devices, FileType.custom greys out files the system doesn't
      // recognize by extension, even valid .wav files.
      final result = await FilePicker.platform.pickFiles(
        type: FileType.any,
        allowMultiple: false,
        withData: true,
      );
      if (result == null || result.files.isEmpty) return;
      final pf = result.files.first;
      debugPrint('[batbox] load: name=${pf.name}, path=${pf.path}, bytes=${pf.bytes?.length}');

      // Get bytes -- prefer pf.bytes (works with content URIs),
      // fall back to reading from path.
      Uint8List? bytes;
      if (pf.bytes != null) {
        bytes = pf.bytes!;
      } else if (pf.path != null) {
        final file = File(pf.path!);
        if (await file.exists()) {
          bytes = await file.readAsBytes();
        }
      }
      if (bytes == null) {
        setState(() => _status = 'Could not read file.');
        _showSnackBar('Could not read file');
        return;
      }

      final samples = _decodeWavToSamples(bytes);
      if (samples.isEmpty) {
        setState(() => _status = 'No PCM data found in WAV.');
        _showSnackBar('No PCM data found in WAV');
        return;
      }
      if (samples.length < 2000) {
        setState(() => _status = 'WAV too short.');
        _showSnackBar('WAV too short');
        return;
      }
      final defaultName = pf.name.replaceAll(RegExp(r'(?i)\.wav$'), '');
      final name = await _promptForName('Name this reference') ?? defaultName;
      final refName = name.isNotEmpty ? name : 'Loaded ${_references.length + 1}';
      await _addReference(refName, samples);
      setState(() => _status = 'Loaded "$refName" from ${pf.name}');
      _showSnackBar('Loaded "$refName"');
    } catch (e, stack) {
      debugPrint('[batbox] load failed: $e');
      debugPrint('[batbox] stack: $stack');
      setState(() => _status = 'Load failed: $e');
      _showSnackBar('Load failed: $e');
    }
  }

  Future<void> _importAudioFile() async {
    try {
      debugPrint('[batbox] import: opening file picker');
      final result = await FilePicker.platform.pickFiles(type: FileType.audio, allowMultiple: false, withData: true);
      if (result == null || result.files.isEmpty) {
        debugPrint('[batbox] import: no file picked');
        return;
      }
      final pf = result.files.first;
      debugPrint('[batbox] import: picked name=${pf.name}, path=${pf.path}, bytes=${pf.bytes?.length ?? "null"}, ext=${pf.extension}');
      if (pf.path == null && pf.bytes == null) {
        debugPrint('[batbox] import: both path and bytes are null!');
        setState(() => _status = 'Could not access file.');
        _showSnackBar('Could not access file');
        return;
      }
      debugPrint('[batbox] import: name=${pf.name}, path=${pf.path}, bytes=${pf.bytes?.length}');

      // Copy picked file to a temp location -- content URIs from Android
      // file pickers often can't be read directly by ffmpeg or dart:io.
      final tempDir = await getTemporaryDirectory();
      final ext = pf.extension?.toLowerCase() ?? 'wav';
      final tempPath = '${tempDir.path}/import_input.$ext';
      final tempFile = File(tempPath);
      try {
        if (pf.bytes != null) {
          await tempFile.writeAsBytes(pf.bytes!);
        } else if (pf.path != null) {
          final source = File(pf.path!);
          if (await source.exists()) {
            await source.copy(tempPath);
          } else {
            setState(() => _status = 'Source file not found.');
            _showSnackBar('Source file not found');
            return;
          }
        }
      } catch (e) {
        debugPrint('[batbox] failed to copy picked file: $e');
        setState(() => _status = 'Failed to access picked file: $e');
        _showSnackBar('Failed to access file: $e');
        return;
      }
      if (!await tempFile.exists()) {
        setState(() => _status = 'Failed to access picked file.');
        return;
      }

      List<double> samples;
      if (ext == 'wav') {
        samples = _decodeWavToSamples(await tempFile.readAsBytes());
      } else {
        setState(() => _status = 'Converting ${pf.name}...');
        samples = await _convertAudioToPcm(tempFile);
      }

      // Clean up temp input
      try { await tempFile.delete(); } catch (_) {}

      if (samples.isEmpty) {
        setState(() => _status = 'No audio data found in file.');
        return;
      }
      if (samples.length < 2000) {
        setState(() => _status = 'Audio too short.');
        return;
      }
      final name = await _promptForName('Name this reference');
      final refName = (name != null && name.isNotEmpty) ? name : 'Imported ${_references.length + 1}';
      await _addReference(refName, samples);
      setState(() => _status = 'Imported "$refName" (${samples.length} samples).');
      _showSnackBar('Imported "$refName"');
    } catch (e, stack) {
      debugPrint('[batbox] import failed: $e');
      debugPrint('[batbox] stack: $stack');
      setState(() => _status = 'Import failed: $e');
      _showSnackBar('Import failed: $e');
    }
  }

  Future<List<double>> _convertAudioToPcm(File sourceFile) async {
    final tempDir = await getTemporaryDirectory();
    final outputPath = '${tempDir.path}/imported_ref.wav';
    final outputFile = File(outputPath);
    if (await outputFile.exists()) await outputFile.delete();

    final cmd = ['-y', '-i', sourceFile.path, '-ar', '44100', '-ac', '1', '-sample_fmt', 's16', outputPath];
    final session = await FFmpegKit.execute(cmd.join(' '));
    final returnCode = await session.getReturnCode();
    if (!ReturnCode.isSuccess(returnCode)) {
      throw Exception('Audio conversion failed (code ${returnCode?.getValue()}).');
    }
    if (!await outputFile.exists()) throw Exception('Conversion produced no output.');
    return _decodeWavToSamples(await outputFile.readAsBytes());
  }

  // ===========================================================================
  // Audio signal processing
  // ===========================================================================

  List<double> _downsample(List<double> input, int factor) {
    if (input.isEmpty || factor <= 1) return List<double>.from(input);
    final out = <double>[];
    for (var i = 0; i + factor <= input.length; i += factor) {
      double sum = 0.0;
      for (var j = 0; j < factor; j++) sum += input[i + j];
      out.add(sum / factor);
    }
    return out;
  }

  List<double> _preEmphasis(List<double> input) {
    if (input.isEmpty) return input;
    final out = List<double>.filled(input.length, 0.0);
    out[0] = input[0];
    for (var i = 1; i < input.length; i++) out[i] = input[i] - 0.95 * input[i - 1];
    return out;
  }

  List<double> _computeEnvelope(List<double> input, int windowSize) {
    if (input.isEmpty || windowSize <= 0) return [];
    final out = <double>[];
    for (var i = 0; i + windowSize <= input.length; i += windowSize) {
      double sum = 0.0;
      for (var j = 0; j < windowSize; j++) sum += input[i + j] * input[i + j];
      out.add(sqrt(sum / windowSize));
    }
    return out;
  }

  double _signalEnergy(List<double> s) {
    if (s.isEmpty) return 0.0;
    double sum = 0.0;
    for (final v in s) sum += v * v;
    return sqrt(sum / s.length);
  }

  /// Compute a 128-point FFT magnitude spectrum (first 64 bins) of the
  /// most recent 128 samples of the downsampled live buffer.
  List<double> _computeSpectrum() {
    const fftSize = 128;
    if (_liveDown.length < fftSize) return List.filled(64, 0.0);
    final real = List<double>.filled(fftSize, 0.0);
    final imag = List<double>.filled(fftSize, 0.0);
    final start = _liveDown.length - fftSize;
    for (var i = 0; i < fftSize; i++) {
      // Hamming window
      final w = 0.54 - 0.46 * cos(2 * pi * i / (fftSize - 1));
      real[i] = _liveDown[start + i] * w;
    }
    _inPlaceFFT(real, imag);
    final mag = List<double>.filled(64, 0.0);
    for (var i = 0; i < 64; i++) {
      mag[i] = sqrt(real[i] * real[i] + imag[i] * imag[i]);
    }
    // Normalize
    var maxMag = 0.0;
    for (final m in mag) if (m > maxMag) maxMag = m;
    if (maxMag > 0) {
      for (var i = 0; i < 64; i++) mag[i] /= maxMag;
    }
    return mag;
  }

  /// In-place radix-2 Cooley-Tukey FFT.
  void _inPlaceFFT(List<double> real, List<double> imag) {
    final n = real.length;
    // Bit reversal
    for (var i = 1, j = 0; i < n; i++) {
      var bit = n >> 1;
      for (; (j & bit) != 0; bit >>= 1) j ^= bit;
      j ^= bit;
      if (i < j) {
        double t;
        t = real[i]; real[i] = real[j]; real[j] = t;
        t = imag[i]; imag[i] = imag[j]; imag[j] = t;
      }
    }
    // Butterfly
    for (var len = 2; len <= n; len <<= 1) {
      final angle = -2.0 * pi / len;
      final wlenR = cos(angle);
      final wlenI = sin(angle);
      for (var i = 0; i < n; i += len) {
        var wR = 1.0;
        var wI = 0.0;
        for (var j = 0; j < len ~/ 2; j++) {
          final uR = real[i + j];
          final uI = imag[i + j];
          final tR = real[i + j + len ~/ 2];
          final tI = imag[i + j + len ~/ 2];
          final vR = tR * wR - tI * wI;
          final vI = tR * wI + tI * wR;
          real[i + j] = uR + vR;
          imag[i + j] = uI + vI;
          real[i + j + len ~/ 2] = uR - vR;
          imag[i + j + len ~/ 2] = uI - vI;
          final newWR = wR * wlenR - wI * wlenI;
          wI = wR * wlenI + wI * wlenR;
          wR = newWR;
        }
      }
    }
  }

  // ===========================================================================
  // Listening + match detection
  // ===========================================================================

  Future<void> _toggleListening() async {
    if (_isListening) {
      await _stopListening();
      return;
    }
    if (!_hasReference) {
      setState(() => _status = 'Record or import a reference first.');
      return;
    }
    await _requestPermissions();
    if (!await _audioRecorder.hasPermission()) {
      setState(() => _status = 'Microphone permission denied.');
      return;
    }

    _photoTriggered = false;
    _isCapturingPhoto = false;
    _sessionPeakSimilarity = 0.0;
    _currentBestSimilarity = 0.0;
    _photosTakenThisSession = 0;
    _burstsThisSession = 0;
    _consecutiveMatchCount = 0;
    _adaptiveNoiseFloor = 0.0;
    _liveSamples.clear();
    _liveDown.clear();
    _spectrogramFrames.clear();
    _similarityHistory.clear();
    _lastTriggerTime = DateTime.fromMillisecondsSinceEpoch(0);
    _lastLoudAudioTime = DateTime.now();
    _currentSessionId = DateTime.now().toIso8601String().replaceAll(':', '-').substring(0, 19);

    if (!_testMode && _photoCountMode.takesPhotos) {
      try { await _initializeCamera(); }
      catch (e) { setState(() => _status = 'Camera init failed: $e'); return; }
    }

    try {
      _audioSubscription?.cancel();
      final stream = await _audioRecorder.startStream(_recordConfig);
      _audioSubscription = stream.listen((Uint8List event) {
        if (_isCapturingPhoto) return;
        _processIncomingChunk(event);
      });
      setState(() {
        _isListening = true;
        _microphoneLevel = 0.0;
        _status = _testMode
            ? 'TEST MODE: Listening...'
            : 'Listening... (${_photoCountMode.label})';
      });
      // Start auto-stop timer
      if (_autoStopOnSilence && !_testMode) {
        _autoStopTimer?.cancel();
        _autoStopTimer = Timer(Duration(seconds: _autoStopTimeoutSec), () {
          if (_isListening) {
            _stopListening();
            _showSnackBar('Auto-stopped: silence detected for ${_autoStopTimeoutSec}s');
          }
        });
      }
    } catch (e) {
      setState(() => _status = 'Unable to start listening: $e');
      await _disposeCamera();
    }
  }

  Future<void> _toggleTestRecognition() async {
    if (_isListening) { await _stopListening(); return; }
    if (!_hasReference) { setState(() => _status = 'Record/import a reference first.'); return; }
    _testMode = true;
    await _toggleListening();
  }

  Future<void> _stopListening() async {
    _autoStopTimer?.cancel();
    await _stopAudioStream();
    await _disposeCamera();
    setState(() {
      _isListening = false;
      _testMode = false;
      _microphoneLevel = 0.0;
      _status = _photosTakenThisSession > 0
          ? 'Stopped. Took ${_photosTakenThisSession} photo(s) in ${_burstsThisSession} burst(s).'
          : 'Listening stopped.';
    });
    await _refreshPhotoSessions();
  }

  Future<void> _stopAudioStream() async {
    final sub = _audioSubscription;
    _audioSubscription = null;
    if (sub != null) { try { await sub.cancel(); } catch (_) {} }
    try {
      if (await _audioRecorder.isRecording()) {
        await _audioRecorder.stop().timeout(const Duration(seconds: 2), onTimeout: () => null);
      }
    } catch (_) {}
  }

  void _processIncomingChunk(Uint8List bytes) {
    final chunkSamples = pcm16ToDoubles(bytes);
    _liveSamples.addAll(chunkSamples);

    final chunkPeak = chunkSamples.fold<double>(0.0, (c, s) => max(c, s.abs()));
    if (mounted) setState(() => _microphoneLevel = max(_microphoneLevel * 0.65, chunkPeak));

    final maxLiveLen = _referenceSamples.length * 2;
    if (_liveSamples.length > maxLiveLen) {
      _liveSamples.removeRange(0, _liveSamples.length - maxLiveLen);
    }
    if (_referenceSamples.isEmpty || _liveSamples.length < 1000) return;

    _liveDown.clear();
    _liveDown.addAll(_downsample(_liveSamples, 10));

    if (_referenceDown.isEmpty || _liveDown.length < _referenceProcessed.length) return;

    final maxLiveDownLen = _referenceProcessed.length * 2;
    if (_liveDown.length > maxLiveDownLen) {
      _liveDown.removeRange(0, _liveDown.length - maxLiveDownLen);
    }

    // Spectrogram
    final spectrum = _computeSpectrum();
    _spectrogramFrames.add(spectrum);
    if (_spectrogramFrames.length > _maxSpectrogramFrames) _spectrogramFrames.removeAt(0);

    // Energy gating
    final liveEnergy = _signalEnergy(_liveDown);
    if (liveEnergy < _silenceThreshold) {
      _currentBestSimilarity = 0.0;
      _consecutiveMatchCount = 0;
      if (mounted) setState(() {});
      return;
    }
    _lastLoudAudioTime = DateTime.now();

    // Adaptive noise floor
    if (liveEnergy < _referenceEnergy * 0.5) {
      _adaptiveNoiseFloor = _adaptiveNoiseFloor * 0.95 + liveEnergy * 0.05;
    }

    // Matching
    final liveProcessed = _preEmphasis(_liveDown);
    final pcmSim = bestSimilarityScore(_referenceProcessed, liveProcessed, stepOverride: 1);
    final liveEnv = _computeEnvelope(_liveDown, 44);
    final envSim = _referenceEnvelope.isNotEmpty && liveEnv.length >= _referenceEnvelope.length
        ? bestSimilarityScore(_referenceEnvelope, liveEnv, stepOverride: 1) : 0.0;
    final similarity = envSim * 0.6 + pcmSim * 0.4;

    if (similarity > _sessionPeakSimilarity) _sessionPeakSimilarity = similarity;
    _currentBestSimilarity = similarity;

    // Update history
    _similarityHistory.add(similarity);
    if (_similarityHistory.length > _maxHistoryLen) _similarityHistory.removeAt(0);

    // Reset auto-stop timer (loud audio detected)
    if (_autoStopOnSilence && !_testMode && _autoStopTimer != null) {
      _autoStopTimer!.cancel();
      _autoStopTimer = Timer(Duration(seconds: _autoStopTimeoutSec), () {
        if (_isListening) { _stopListening(); _showSnackBar('Auto-stopped: silence'); }
      });
    }

    if (mounted) setState(() {});

    // Debounce
    if (similarity >= _triggerThreshold) {
      _consecutiveMatchCount++;
    } else {
      _consecutiveMatchCount = 0;
    }
    if (_consecutiveMatchCount < _minMatchChunks) return;

    // Refractory period
    final now = DateTime.now();
    final refractory = Duration(milliseconds: _refractoryPeriodMs);
    if (now.difference(_lastTriggerTime) < refractory) return;
    _lastTriggerTime = now;

    // Haptic feedback
    if (_hapticOnMatch) HapticFeedback.heavyImpact();

    // Flash
    _flashActive = true;
    _flashTimer?.cancel();
    _flashTimer = Timer(const Duration(milliseconds: 250), () {
      if (mounted) setState(() => _flashActive = false);
    });

    if (_testMode || !_photoCountMode.takesPhotos) {
      if (mounted) setState(() => _status = 'Match! sim=${similarity.toStringAsFixed(3)}');
      return;
    }

    _photoTriggered = true;
    _isCapturingPhoto = true;
    _burstsThisSession++;
    if (mounted) setState(() => _status = 'Match! Taking ${_photoCountMode.burstSize} photo(s)...');
    unawaited(_triggerPhoto().catchError((Object e) {
      if (mounted) setState(() { _photoTriggered = false; _isCapturingPhoto = false; _flashActive = false; _cameraLaunchInProgress = false; _status = 'Trigger failed: $e'; });
    }));
  }

  // ===========================================================================
  // Photo capture
  // ===========================================================================

  Future<void> _takeSinglePhoto() async {
    if (_cameraController == null || !_cameraController!.value.isInitialized) {
      await _initializeCamera().timeout(const Duration(seconds: 5),
          onTimeout: () => throw Exception('Camera init timed out.'));
    }
    if (_cameraController == null || !_cameraController!.value.isInitialized) {
      throw Exception('Camera init failed.');
    }
    final photo = await _cameraController!.takePicture().timeout(const Duration(seconds: 5),
        onTimeout: () => throw Exception('Camera capture timed out.'));
    final saved = await _saveCapturedPhoto(photo.path);
    if (mounted) setState(() => _lastSavedPhotoPath = saved.path);
  }

  Future<void> _manualTrigger() async {
    if (_cameraLaunchInProgress) return;
    _cameraLaunchInProgress = true;
    setState(() => _status = 'Taking photo...');
    try {
      final perm = await Permission.camera.status;
      if (!perm.isGranted) {
        final req = await Permission.camera.request();
        if (!req.isGranted) { setState(() => _status = 'Camera permission denied.'); return; }
      }
      await _takeSinglePhoto();
      if (mounted) setState(() => _status = 'Photo saved.');
    } catch (e) {
      if (mounted) setState(() => _status = 'Capture failed: $e');
    } finally {
      _photoTriggered = false;
      _isCapturingPhoto = false;
      if (!_isListening) await _disposeCamera();
      if (mounted) setState(() => _cameraLaunchInProgress = false);
    }
  }

  Future<void> _triggerPhoto() async {
    if (_cameraLaunchInProgress) return;
    _cameraLaunchInProgress = true;
    final burstSize = _photoCountMode.burstSize;
    final stopAfter = _photoCountMode.stopAfterFirstMatch;
    setState(() { _photoTriggered = true; _isCapturingPhoto = true; });
    try {
      for (var i = 0; i < burstSize; i++) {
        await _takeSinglePhoto();
        _photosTakenThisSession++;
        if (mounted) setState(() => _status = 'Burst: ${i + 1}/$burstSize...');
      }
      if (stopAfter) {
        await _stopListening();
      } else {
        _lastTriggerTime = DateTime.now();
        if (mounted) setState(() => _status = 'Burst done. Listening for next...');
      }
    } catch (e) {
      if (mounted) setState(() => _status = 'Capture failed: $e');
    } finally {
      _photoTriggered = false;
      _isCapturingPhoto = false;
      if (!_isListening) await _disposeCamera();
      if (mounted) setState(() => _cameraLaunchInProgress = false);
    }
  }

  Future<void> _initializeCamera() async {
    if (_cameraController != null && _cameraController!.value.isInitialized) return;
    _availableCameras = await availableCameras();
    if (_availableCameras.isEmpty) throw Exception('No cameras.');
    final camera = _availableCameras.firstWhere(
      (c) => c.lensDirection == CameraLensDirection.back,
      orElse: () => _availableCameras.first,
    );
    _cameraController = CameraController(camera, _resolutionSetting.preset, enableAudio: false);
    await _cameraController!.initialize();
    await _applyFlashMode();
  }

  Future<void> _applyFlashMode() async {
    if (_cameraController == null || !_cameraController!.value.isInitialized) return;
    try {
      final fm = _flashModeSetting == FlashModeSetting.off ? FlashMode.off
          : _flashModeSetting == FlashModeSetting.auto ? FlashMode.auto
          : _flashModeSetting == FlashModeSetting.always ? FlashMode.always
          : FlashMode.torch;
      await _cameraController!.setFlashMode(fm);
    } catch (_) {}
  }

  Future<void> _disposeCamera() async {
    _cameraController?.dispose();
    _cameraController = null;
  }

  // ===========================================================================
  // Photo storage + sessions
  // ===========================================================================

  Future<Directory> _photoBaseDirectory() async {
    final dir = await getApplicationDocumentsDirectory();
    final batboxDir = Directory('${dir.path}${Platform.pathSeparator}batbox');
    if (!await batboxDir.exists()) await batboxDir.create(recursive: true);
    return batboxDir;
  }

  Future<File> _saveCapturedPhoto(String sourcePath) async {
    final baseDir = await _photoBaseDirectory();
    // Use session subfolder
    final sessionDir = Directory('${baseDir.path}${Platform.pathSeparator}$_currentSessionId');
    if (!await sessionDir.exists()) await sessionDir.create(recursive: true);
    final ts = DateTime.now().toIso8601String().replaceAll(':', '-');
    final dest = File('${sessionDir.path}${Platform.pathSeparator}batbox-$ts.jpg');
    return File(sourcePath).copy(dest.path);
  }

  Future<void> _refreshPhotoSessions() async {
    try {
      final baseDir = await _photoBaseDirectory();
      final entries = await baseDir.list().toList();
      _photosBySession.clear();
      _allPhotoPaths.clear();

      // Collect session directories
      final sessionDirs = <Directory>[];
      for (final e in entries) {
        if (e is Directory) {
          sessionDirs.add(e);
        } else if (e is File && e.path.toLowerCase().endsWith('.jpg')) {
          // Old-format photos in root
          _photosBySession.putIfAbsent('Previous', () => []).add(e.path);
          _allPhotoPaths.add(e.path);
        }
      }

      // Sort sessions newest first (by dir name, which is ISO timestamp)
      sessionDirs.sort((a, b) => b.path.compareTo(a.path));
      for (final dir in sessionDirs) {
        final label = dir.path.split(Platform.pathSeparator).last;
        final photos = <String>[];
        final files = await dir.list().toList();
        for (final f in files) {
          if (f is File && f.path.toLowerCase().endsWith('.jpg')) {
            photos.add(f.path);
          }
        }
        photos.sort((a, b) => b.compareTo(a));
        if (photos.isNotEmpty) {
          _photosBySession[label] = photos;
          _allPhotoPaths.addAll(photos);
        }
      }
      _allPhotoPaths.sort((a, b) => b.compareTo(a));
      _selectedPhotoPaths.removeWhere((p) => !_allPhotoPaths.contains(p));
      if (mounted) setState(() {});
    } catch (e) {
      debugPrint('Refresh photos failed: $e');
    }
  }

  // ===========================================================================
  // Photo gallery actions
  // ===========================================================================

  void _togglePhotoSelection(String path) {
    setState(() {
      if (_selectedPhotoPaths.contains(path)) {
        _selectedPhotoPaths.remove(path);
      } else {
        _selectedPhotoPaths.add(path);
        _selectionMode = true;
      }
      if (_selectedPhotoPaths.isEmpty) _selectionMode = false;
    });
  }

  void _selectAllPhotos() {
    setState(() {
      _selectionMode = true;
      _selectedPhotoPaths..clear()..addAll(_allPhotoPaths);
    });
  }

  void _exitSelectionMode() {
    setState(() { _selectionMode = false; _selectedPhotoPaths.clear(); });
  }

  Future<void> _deleteSelectedPhotos() async {
    debugPrint('[batbox] _deleteSelectedPhotos called, ${_selectedPhotoPaths.length} selected');
    if (_selectedPhotoPaths.isEmpty) {
      _showSnackBar('No photos selected');
      return;
    }
    if (!mounted) return;
    // Use rootNavigatorKey context as fallback for the messenger.
    ScaffoldMessengerState? messenger;
    try { messenger = ScaffoldMessenger.of(context); } catch (_) {}
    messenger ??= rootNavigatorKey.currentContext != null
        ? ScaffoldMessenger.of(rootNavigatorKey.currentContext!)
        : null;
    final toDelete = List<String>.from(_selectedPhotoPaths);
    var deleted = 0;
    final errors = <String>[];
    for (final path in toDelete) {
      try {
        final f = File(path);
        if (await f.exists()) { await f.delete(); deleted++; debugPrint('[batbox] deleted: $path'); }
        else { deleted++; debugPrint('[batbox] already gone: $path'); }
      } catch (e) {
        debugPrint('[batbox] FAILED to delete $path: $e');
        errors.add(e.toString());
      }
    }
    if (mounted) {
      setState(() {
        _selectedPhotoPaths.clear();
        _selectionMode = false;
      });
      await _refreshPhotoSessions();
    }
    final msg = errors.isEmpty
        ? 'Deleted $deleted photo(s)'
        : 'Deleted $deleted of ${toDelete.length}. Error: ${errors.first}';
    debugPrint('[batbox] delete result: $msg');
    if (messenger != null) {
      messenger.showSnackBar(SnackBar(content: Text(msg), duration: const Duration(seconds: 3)));
    } else {
      _showSnackBar(msg);
    }
  }

  Future<void> _deleteAllPhotos() async {
    final confirm = await showDialog<bool>(
      context: rootNavigatorKey.currentContext ?? context, useRootNavigator: true,
      builder: (ctx) => AlertDialog(
        title: const Text('Delete ALL photos?'),
        content: Text('Permanently delete all ${_allPhotoPaths.length} photo(s)?'),
        actions: [
          TextButton(onPressed: () => Navigator.pop(ctx, false), child: const Text('Cancel')),
          FilledButton(style: FilledButton.styleFrom(backgroundColor: Colors.red),
            onPressed: () => Navigator.pop(ctx, true), child: const Text('Delete all')),
        ],
      ),
    );
    if (confirm != true) return;
    final messenger = ScaffoldMessenger.of(context);
    var deleted = 0;
    for (final path in _allPhotoPaths) {
      try { final f = File(path); if (await f.exists()) { await f.delete(); deleted++; } } catch (_) {}
    }
    // Also remove session directories
    try {
      final baseDir = await _photoBaseDirectory();
      final entries = await baseDir.list().toList();
      for (final e in entries) {
        if (e is Directory) await e.delete(recursive: true);
      }
    } catch (_) {}
    _selectedPhotoPaths.clear();
    _selectionMode = false;
    await _refreshPhotoSessions();
    messenger.showSnackBar(SnackBar(content: Text('Deleted $deleted photo(s)')));
  }

  Future<void> _saveAllToFolder() async {
    if (_allPhotoPaths.isEmpty) return;
    final messenger = ScaffoldMessenger.of(context);
    Directory targetDir;
    try {
      final picked = await FilePicker.platform.getDirectoryPath(dialogTitle: 'Choose folder');
      if (picked != null && await Directory(picked).exists()) {
        targetDir = Directory(picked);
      } else {
        targetDir = await _getDefaultSaveDir();
      }
    } catch (_) {
      targetDir = await _getDefaultSaveDir();
    }
    var saved = 0;
    for (final path in _allPhotoPaths) {
      try {
        final f = File(path);
        if (!await f.exists()) continue;
        final name = f.uri.pathSegments.last;
        await f.copy('${targetDir.path}${Platform.pathSeparator}$name');
        saved++;
      } catch (_) {}
    }
    messenger.showSnackBar(SnackBar(content: Text('Saved $saved photo(s) to ${targetDir.path}')));
  }

  Future<Directory> _getDefaultSaveDir() async {
    if (Platform.isAndroid) {
      final d = Directory('/storage/emulated/0/Pictures/BatBox');
      if (!await d.exists()) await d.create(recursive: true);
      return d;
    }
    final dir = await getApplicationDocumentsDirectory();
    return dir;
  }

  Future<void> _saveSelectedToFolder() async {
    if (_selectedPhotoPaths.isEmpty) return;
    final messenger = ScaffoldMessenger.of(context);
    Directory targetDir;
    try {
      final picked = await FilePicker.platform.getDirectoryPath(dialogTitle: 'Choose folder');
      if (picked != null && await Directory(picked).exists()) {
        targetDir = Directory(picked);
      } else {
        targetDir = await _getDefaultSaveDir();
      }
    } catch (_) {
      targetDir = await _getDefaultSaveDir();
    }
    var saved = 0;
    for (final path in _selectedPhotoPaths) {
      try {
        final f = File(path);
        if (!await f.exists()) continue;
        final name = f.uri.pathSegments.last;
        await f.copy('${targetDir.path}${Platform.pathSeparator}$name');
        saved++;
      } catch (_) {}
    }
    setState(() { _selectionMode = false; _selectedPhotoPaths.clear(); });
    messenger.showSnackBar(SnackBar(content: Text('Saved $saved photo(s)')));
  }

  Future<void> _sharePhoto(String path) async {
    try {
      await Share.shareXFiles([XFile(path)]);
    } catch (e) {
      _showSnackBar('Share failed: $e');
    }
  }

  void _viewPhoto(String path) {
    final index = _allPhotoPaths.indexOf(path);
    final nav = rootNavigatorKey.currentState;
    if (nav == null) return;
    nav.push(MaterialPageRoute<void>(
      builder: (_) => _PhotoViewerScreen(
        photos: List<String>.from(_allPhotoPaths),
        initialIndex: index < 0 ? 0 : index,
        onShare: _sharePhoto,
      ),
    ));
  }

  void _showSnackBar(String msg) {
    if (!mounted) return;
    try {
      ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text(msg), duration: const Duration(seconds: 3)));
    } catch (_) {}
  }

  void _showInstructions() {
    showDialog<void>(
      context: rootNavigatorKey.currentContext ?? context, useRootNavigator: true,
      builder: (ctx) => AlertDialog(
        title: const Text('Instructions'),
        content: const SingleChildScrollView(child: Text(
          '1. Record or import a reference sound on the Reference tab.\n'
          '2. (Optional) Use "Test recognition" to tune the threshold.\n'
          '3. Switch to the Trigger tab, pick photo count + flash mode.\n'
          '4. Press Start listening, then make the reference sound.\n'
          '5. View/manage photos on the Photos tab.\n\n'
          'When a match is detected, the app takes a BURST of photos as fast as possible.\n'
          'Settings persist across app restarts.',
        )),
        actions: [TextButton(onPressed: () => Navigator.pop(ctx), child: const Text('OK'))],
      ),
    );
  }

  // ===========================================================================
  // WAV encode / decode
  // ===========================================================================

  Future<List<int>> _encodeWav(List<double> samples) async {
    const sr = 44100, ba = 2;
    final br = sr * ba, ds = samples.length * 2;
    final buf = BytesBuilder();
    void w32(int v) { buf.addByte(v & 0xff); buf.addByte((v >> 8) & 0xff); buf.addByte((v >> 16) & 0xff); buf.addByte((v >> 24) & 0xff); }
    void w16(int v) { buf.addByte(v & 0xff); buf.addByte((v >> 8) & 0xff); }
    buf.add(utf8.encode('RIFF')); w32(36 + ds); buf.add(utf8.encode('WAVE'));
    buf.add(utf8.encode('fmt ')); w32(16); w16(1); w16(1); w32(sr); w32(br); w16(ba); w16(16);
    buf.add(utf8.encode('data')); w32(ds);
    for (final s in samples) { final v = (s.clamp(-1.0, 1.0) * 32767).round(); w16(v < 0 ? v + 65536 : v); }
    return buf.takeBytes();
  }

  List<double> _decodeWavToSamples(Uint8List bytes) {
    final tag = utf8.encode('data');
    int idx = -1;
    for (int i = 0; i + 3 < bytes.length; i++) {
      if (bytes[i] == tag[0] && bytes[i+1] == tag[1] && bytes[i+2] == tag[2] && bytes[i+3] == tag[3]) { idx = i + 4; break; }
    }
    if (idx < 0 || idx + 4 > bytes.length) return [];
    final bd = ByteData.sublistView(bytes);
    final ds = bd.getUint32(idx, Endian.little);
    final start = idx + 4, end = min(bytes.length, start + ds);
    if (start >= end) return [];
    return pcm16ToDoubles(Uint8List.fromList(bytes.sublist(start, end)));
  }

  // ===========================================================================
  // BUILD
  // ===========================================================================

  @override
  Widget build(BuildContext context) {
    // Override the default ErrorWidget (which renders nothing in release
    // mode = white/black screen) with one that shows the error text.
    // MUST be self-contained (Directionality + Scaffold) because errors
    // during the first frame have no inherited widget ancestors.
    ErrorWidget.builder = (FlutterErrorDetails details) {
      return Directionality(
        textDirection: TextDirection.ltr,
        child: Scaffold(
          backgroundColor: Colors.red.shade50,
          body: SafeArea(
            child: Padding(
              padding: const EdgeInsets.all(16),
              child: Column(
                mainAxisAlignment: MainAxisAlignment.center,
                children: [
                  const Icon(Icons.error_outline, size: 48, color: Colors.red),
                  const SizedBox(height: 8),
                  const Text('Something went wrong', style: TextStyle(fontSize: 18, fontWeight: FontWeight.bold)),
                  const SizedBox(height: 8),
                  Text(details.exception.toString(), textAlign: TextAlign.center, style: const TextStyle(fontSize: 12)),
                ],
              ),
            ),
          ),
        ),
      );
    };
    return MaterialApp(
      title: 'BatBox',
      theme: ThemeData(colorSchemeSeed: Colors.deepPurple, useMaterial3: true),
      navigatorKey: rootNavigatorKey,
      home: Scaffold(
        appBar: AppBar(
          title: const Text('BatBox'),
          bottom: TabBar(
            controller: _tabController,
            tabs: const [
              Tab(icon: Icon(Icons.sensors), text: 'Trigger'),
              Tab(icon: Icon(Icons.graphic_eq), text: 'Reference'),
              Tab(icon: Icon(Icons.photo_library), text: 'Photos'),
            ],
          ),
          actions: [
            IconButton(icon: const Icon(Icons.help_outline), onPressed: _showInstructions, tooltip: 'Instructions'),
          ],
        ),
        body: Stack(
          children: [
            AnimatedContainer(
              duration: const Duration(milliseconds: 180),
              color: _flashActive ? Colors.black.withValues(alpha: 0.85) : Colors.transparent,
            ),
            SafeArea(
              child: TabBarView(
                controller: _tabController,
                children: [_buildTriggerTab(), _buildReferenceTab(), _buildPhotosTab()],
              ),
            ),
          ],
        ),
      ),
    );
  }

  // ---------------------------------------------------------------------------
  // Trigger tab
  // ---------------------------------------------------------------------------

  Widget _buildTriggerTab() {
    return SingleChildScrollView(
      padding: const EdgeInsets.symmetric(horizontal: 20, vertical: 12),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.center,
        children: [
          const Text('Trigger', style: TextStyle(fontSize: 22, fontWeight: FontWeight.bold)),
          const SizedBox(height: 8),
          Container(
            padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 4),
            decoration: BoxDecoration(color: Colors.deepPurple.withValues(alpha: 0.15), borderRadius: BorderRadius.circular(6)),
            child: const Text('BUILD v10.9 - 2026-06-30 01:30 UTC', style: TextStyle(fontSize: 12, fontWeight: FontWeight.bold, color: Colors.deepPurple)),
          ),
          const SizedBox(height: 16),

          // Active reference
          if (_references.isNotEmpty)
            Row(mainAxisAlignment: MainAxisAlignment.center, children: [
              const Text('Reference: '),
              DropdownButton<String>(
                // Only set value if it exists in the items list, otherwise null.
                // Setting a value not in items throws an assertion error = white screen.
                value: _references.any((r) => r.name == _activeReferenceName) ? _activeReferenceName : null,
                items: _references.map((r) => DropdownMenuItem(value: r.name, child: Text(r.name))).toList(),
                onChanged: (v) { if (v != null) _switchToReference(v); },
              ),
            ]),
          const SizedBox(height: 8),

          // Mode dropdowns
          _buildDropdownRow('Photo mode', PhotoCountMode.values, _photoCountMode, (v) { setState(() => _photoCountMode = v); _saveSettings(); }),
          _buildDropdownRow('Flash', FlashModeSetting.values, _flashModeSetting, (v) { setState(() => _flashModeSetting = v); _saveSettings(); _applyFlashMode(); }),
          _buildDropdownRow('Recognition', RecognitionMode.values, _recognitionMode, (v) { setState(() => _recognitionMode = v); _saveSettings(); }),
          _buildDropdownRow('Resolution', ResolutionSetting.values, _resolutionSetting, (v) { setState(() => _resolutionSetting = v); _saveSettings(); }),
          const SizedBox(height: 8),

          // Refractory period slider
          Text('Refractory period: ${(_refractoryPeriodMs / 1000).toStringAsFixed(1)}s', style: Theme.of(context).textTheme.bodySmall),
          SizedBox(width: 280, child: Slider(
            value: _refractoryPeriodMs.toDouble(), min: 200, max: 5000, divisions: 48,
            label: '${(_refractoryPeriodMs / 1000).toStringAsFixed(1)}s',
            onChanged: (v) => setState(() => _refractoryPeriodMs = v.round()),
            onChangeEnd: (_) => _saveSettings(),
          )),
          const SizedBox(height: 8),

          // Toggles: haptic + auto-stop
          SwitchListTile(
            title: const Text('Haptic feedback on match', style: TextStyle(fontSize: 14)),
            value: _hapticOnMatch,
            onChanged: (v) { setState(() => _hapticOnMatch = v); _saveSettings(); },
            dense: true,
          ),
          SwitchListTile(
            title: const Text('Auto-stop on silence', style: TextStyle(fontSize: 14)),
            value: _autoStopOnSilence,
            onChanged: (v) { setState(() => _autoStopOnSilence = v); _saveSettings(); },
            dense: true,
          ),
          if (_autoStopOnSilence) ...[
            Text('Timeout: ${_autoStopTimeoutSec}s', style: Theme.of(context).textTheme.bodySmall),
            SizedBox(width: 280, child: Slider(
              value: _autoStopTimeoutSec.toDouble(), min: 5, max: 120, divisions: 23,
              label: '${_autoStopTimeoutSec}s',
              onChanged: (v) => setState(() => _autoStopTimeoutSec = v.round()),
              onChangeEnd: (_) => _saveSettings(),
            )),
          ],
          const SizedBox(height: 12),

          // Start/stop + manual
          FilledButton.icon(
            onPressed: _isListening || _hasReference ? _toggleListening : null,
            icon: Icon(_isListening ? Icons.stop_circle : Icons.sensors),
            label: Text(_isListening ? 'Stop listening' : 'Start listening'),
          ),
          const SizedBox(height: 8),
          FilledButton.icon(onPressed: _manualTrigger, icon: const Icon(Icons.camera_alt), label: const Text('Take photo manually')),
          const SizedBox(height: 16),

          Text(_status, textAlign: TextAlign.center, style: const TextStyle(fontSize: 16)),
          const SizedBox(height: 12),

          // Live diagnostics + spectrogram
          if (_isListening) ...[
            Text('Mic: ${(_microphoneLevel * 100).round()}%', style: Theme.of(context).textTheme.bodyMedium),
            const SizedBox(height: 4),
            SizedBox(width: 220, child: LinearProgressIndicator(value: _microphoneLevel.clamp(0.0, 1.0), minHeight: 10)),
            const SizedBox(height: 12),
            Text('Similarity: ${_currentBestSimilarity.toStringAsFixed(3)}  (peak: ${_sessionPeakSimilarity.toStringAsFixed(3)})',
              style: TextStyle(fontSize: 14, fontWeight: FontWeight.bold,
                color: _currentBestSimilarity >= _triggerThreshold ? Colors.green : Colors.orange)),
            const SizedBox(height: 8),
            Text('Threshold: ${_triggerThreshold.toStringAsFixed(2)}', style: Theme.of(context).textTheme.bodySmall),
            SizedBox(width: 280, child: Slider(
              value: _triggerThreshold, min: 0.10, max: 0.90, divisions: 80,
              label: _triggerThreshold.toStringAsFixed(2),
              onChanged: (v) => setState(() => _triggerThreshold = v),
              onChangeEnd: (_) => _saveSettings(),
            )),
            if (_photoCountMode.takesPhotos)
              Text('Session: ${_photosTakenThisSession} photo(s), ${_burstsThisSession} burst(s)', style: Theme.of(context).textTheme.bodySmall),
            const SizedBox(height: 12),
            // Spectrogram
            const Text('Spectrogram', style: TextStyle(fontSize: 12, fontWeight: FontWeight.bold)),
            const SizedBox(height: 4),
            Container(
              width: double.infinity, height: 120,
              decoration: BoxDecoration(border: Border.all(color: Colors.grey), color: Colors.black),
              child: CustomPaint(painter: _SpectrogramPainter(frames: _spectrogramFrames), child: const SizedBox.expand()),
            ),
          ],
        ],
      ),
    );
  }

  Widget _buildDropdownRow<T>(String label, List<T> values, T current, ValueChanged<T> onChanged) {
    return Padding(
      padding: const EdgeInsets.symmetric(vertical: 2),
      child: Row(mainAxisAlignment: MainAxisAlignment.center, children: [
        Text('$label: '),
        DropdownButton<T>(
          value: current,
          items: values.map((v) => DropdownMenuItem(value: v, child: Text((v as dynamic).label as String))).toList(),
          onChanged: (v) { if (v != null) onChanged(v); },
        ),
      ]),
    );
  }

  // ---------------------------------------------------------------------------
  // Reference tab
  // ---------------------------------------------------------------------------

  Widget _buildReferenceTab() {
    return SingleChildScrollView(
      padding: const EdgeInsets.symmetric(horizontal: 20, vertical: 12),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.center,
        children: [
          const Text('Reference audio', style: TextStyle(fontSize: 22, fontWeight: FontWeight.bold)),
          const SizedBox(height: 8),

          // Reference library
          if (_references.isNotEmpty) ...[
            const Text('Saved references', style: TextStyle(fontWeight: FontWeight.bold, fontSize: 14)),
            const SizedBox(height: 4),
            ConstrainedBox(
              constraints: const BoxConstraints(maxHeight: 200),
              child: ListView.builder(
                shrinkWrap: true,
                itemCount: _references.length,
                itemBuilder: (ctx, i) {
                  final ref = _references[i];
                  final isActive = ref.name == _activeReferenceName;
                  return ListTile(
                    leading: Icon(isActive ? Icons.check_circle : Icons.radio_button_unchecked,
                        color: isActive ? Colors.deepPurple : Colors.grey),
                    title: Text(ref.name),
                    subtitle: Text('${(ref.samples.length / 44100).toStringAsFixed(1)}s'),
                    trailing: Row(mainAxisSize: MainAxisSize.min, children: [
                      IconButton(icon: const Icon(Icons.play_arrow, size: 20), onPressed: () {
                        _switchToReference(ref.name);
                        _playReferenceSound();
                      }),
                      IconButton(icon: const Icon(Icons.edit, size: 20), onPressed: () async {
                        final newName = await _promptForName('Rename reference');
                        if (newName != null && newName.isNotEmpty) _renameReference(ref.name, newName);
                      }),
                      IconButton(icon: const Icon(Icons.delete, size: 20), onPressed: () => _deleteReference(ref.name)),
                    ]),
                    onTap: () => _switchToReference(ref.name),
                  );
                },
              ),
            ),
            const SizedBox(height: 8),
          ] else
            const Padding(padding: EdgeInsets.all(8), child: Text('No references yet. Record or import one below.', style: TextStyle(color: Colors.grey))),

          const Divider(),
          const SizedBox(height: 8),

          // Record / import / play
          FilledButton.icon(
            onPressed: _toggleReferenceRecording,
            icon: Icon(_isRecordingReference ? Icons.stop : Icons.mic),
            label: Text(_isRecordingReference ? 'Stop recording' : 'Record new reference'),
          ),
          const SizedBox(height: 8),
          OutlinedButton.icon(onPressed: _importAudioFile, icon: const Icon(Icons.file_upload), label: const Text('Import audio (.wav, .m4a, .mp3)')),
          const SizedBox(height: 8),
          // Save / Load reference WAV files
          Row(mainAxisAlignment: MainAxisAlignment.center, children: [
            OutlinedButton.icon(onPressed: _saveReferenceToFile, icon: const Icon(Icons.save), label: const Text('Save .wav')),
            const SizedBox(width: 12),
            OutlinedButton.icon(onPressed: _loadReferenceFromFile, icon: const Icon(Icons.folder_open), label: const Text('Load .wav')),
          ]),
          const SizedBox(height: 8),
          if (_hasReference)
            FilledButton.icon(onPressed: _playReferenceSound, icon: Icon(_isPlayingReference ? Icons.stop : Icons.play_arrow), label: Text(_isPlayingReference ? 'Stop' : 'Play active reference')),
          const SizedBox(height: 8),
          if (_isRecordingReference)
            Text('Recording... ${(_referenceSamples.length / 44100).toStringAsFixed(1)}s', style: const TextStyle(color: Colors.red, fontWeight: FontWeight.bold)),

          const SizedBox(height: 24),
          const Divider(),

          // Test recognition
          const Text('Test recognition', style: TextStyle(fontSize: 18, fontWeight: FontWeight.bold)),
          const SizedBox(height: 4),
          const Text('Listens without taking photos. Shows live similarity\nand histogram for tuning the threshold.', textAlign: TextAlign.center, style: TextStyle(fontSize: 12, color: Colors.grey)),
          const SizedBox(height: 12),
          FilledButton.icon(
            onPressed: _hasReference ? _toggleTestRecognition : null,
            icon: Icon(_isListening && _testMode ? Icons.stop_circle : Icons.science),
            label: Text(_isListening && _testMode ? 'Stop test' : 'Start test'),
          ),

          if (_isListening && _testMode) ...[
            const SizedBox(height: 12),
            Text('Mic: ${(_microphoneLevel * 100).round()}%'),
            const SizedBox(height: 4),
            SizedBox(width: 220, child: LinearProgressIndicator(value: _microphoneLevel.clamp(0.0, 1.0), minHeight: 10)),
            const SizedBox(height: 12),
            Text('Similarity: ${_currentBestSimilarity.toStringAsFixed(3)}  (peak: ${_sessionPeakSimilarity.toStringAsFixed(3)})',
              style: TextStyle(fontSize: 14, fontWeight: FontWeight.bold,
                color: _currentBestSimilarity >= _triggerThreshold ? Colors.green : Colors.orange)),
            const SizedBox(height: 8),
            // Histogram
            const Text('Recent similarity scores', style: TextStyle(fontSize: 12, fontWeight: FontWeight.bold)),
            const SizedBox(height: 4),
            SizedBox(
              width: double.infinity, height: 80,
              child: CustomPaint(painter: _HistogramPainter(scores: _similarityHistory, threshold: _triggerThreshold), child: const SizedBox.expand()),
            ),
            const SizedBox(height: 8),
            Text('Threshold: ${_triggerThreshold.toStringAsFixed(2)}', style: Theme.of(context).textTheme.bodySmall),
            SizedBox(width: 280, child: Slider(
              value: _triggerThreshold, min: 0.10, max: 0.90, divisions: 80,
              label: _triggerThreshold.toStringAsFixed(2),
              onChanged: (v) => setState(() => _triggerThreshold = v),
              onChangeEnd: (_) => _saveSettings(),
            )),
            const SizedBox(height: 8),
            // Spectrogram in test mode too
            const Text('Spectrogram', style: TextStyle(fontSize: 12, fontWeight: FontWeight.bold)),
            const SizedBox(height: 4),
            Container(
              width: double.infinity, height: 100,
              decoration: BoxDecoration(border: Border.all(color: Colors.grey), color: Colors.black),
              child: CustomPaint(painter: _SpectrogramPainter(frames: _spectrogramFrames), child: const SizedBox.expand()),
            ),
          ],

          const SizedBox(height: 16),
          Text(_status, textAlign: TextAlign.center, style: const TextStyle(fontSize: 14)),
        ],
      ),
    );
  }

  // ---------------------------------------------------------------------------
  // Photos tab
  // ---------------------------------------------------------------------------

  Widget _buildPhotosTab() {
    final hasSelection = _selectedPhotoPaths.isNotEmpty;
    return Column(children: [
      // Action bar
      Container(
        color: hasSelection ? Colors.deepPurple.withValues(alpha: 0.1) : Colors.transparent,
        padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 8),
        child: Row(children: [
          Text(hasSelection ? '${_selectedPhotoPaths.length} selected' : '${_allPhotoPaths.length} photo(s)'),
          const Spacer(),
          IconButton(icon: Icon(hasSelection ? Icons.deselect : Icons.select_all),
            tooltip: hasSelection ? 'Deselect all' : 'Select all',
            onPressed: () { if (hasSelection) _exitSelectionMode(); else _selectAllPhotos(); }),
          if (hasSelection) IconButton(icon: const Icon(Icons.save_alt), tooltip: 'Save to folder', onPressed: _saveSelectedToFolder),
          if (hasSelection) IconButton(icon: const Icon(Icons.delete), tooltip: 'Delete selected', onPressed: _deleteSelectedPhotos),
          if (!hasSelection && _allPhotoPaths.isNotEmpty) IconButton(icon: const Icon(Icons.delete_sweep), tooltip: 'Delete all', onPressed: _deleteAllPhotos),
          if (!hasSelection && _allPhotoPaths.isNotEmpty) IconButton(icon: const Icon(Icons.save), tooltip: 'Save all', onPressed: _saveAllToFolder),
          IconButton(icon: const Icon(Icons.refresh), tooltip: 'Refresh', onPressed: _refreshPhotoSessions),
        ]),
      ),
      // Photo grid grouped by session
      Expanded(
        child: _allPhotoPaths.isEmpty
          ? const Center(child: Text('No photos yet.\nTrigger a photo from the Trigger tab.', textAlign: TextAlign.center, style: TextStyle(color: Colors.grey)))
          : ListView.builder(
              itemCount: _photosBySession.length,
              itemBuilder: (ctx, sessionIdx) {
                final sessionLabel = _photosBySession.keys.elementAt(sessionIdx);
                final photos = _photosBySession[sessionLabel]!;
                return ExpansionTile(
                  initiallyExpanded: sessionIdx == 0,
                  title: Text(_formatSessionLabel(sessionLabel)),
                  subtitle: Text('${photos.length} photo(s)'),
                  children: [
                    GridView.builder(
                      shrinkWrap: true,
                      physics: const NeverScrollableScrollPhysics(),
                      padding: const EdgeInsets.all(4),
                      gridDelegate: const SliverGridDelegateWithFixedCrossAxisCount(crossAxisCount: 3, mainAxisSpacing: 4, crossAxisSpacing: 4),
                      itemCount: photos.length,
                      itemBuilder: (ctx, idx) {
                        final path = photos[idx];
                        final selected = _selectedPhotoPaths.contains(path);
                        return ClipRRect(
                          borderRadius: BorderRadius.circular(4),
                          child: Stack(fit: StackFit.expand, children: [
                            // Image -- tap to view
                            GestureDetector(
                              behavior: HitTestBehavior.opaque,
                              onTap: () => _viewPhoto(path),
                              child: Container(color: Colors.grey.shade300, child: Image.file(File(path), fit: BoxFit.cover,
                                errorBuilder: (_, __, ___) => const Center(child: Icon(Icons.broken_image, color: Colors.white70)))),
                            ),
                            // Selection tint -- below checkbox so it doesn't block taps.
                            // Uses IgnorePointer so it never intercepts gestures.
                            if (selected)
                              Positioned.fill(
                                child: IgnorePointer(
                                  child: Container(color: Colors.deepPurple.withValues(alpha: 0.3)),
                                ),
                              ),
                            // Checkbox -- always on top, always tappable
                            Positioned(top: 4, right: 4, child: GestureDetector(
                              behavior: HitTestBehavior.opaque,
                              onTap: () {
                                debugPrint('[batbox] checkbox tapped: $path');
                                _togglePhotoSelection(path);
                              },
                              child: Container(width: 32, height: 32,
                                decoration: const BoxDecoration(color: Colors.black54, shape: BoxShape.circle),
                                child: Icon(selected ? Icons.check_circle : Icons.radio_button_unchecked,
                                  color: selected ? Colors.deepPurple : Colors.white, size: 24)),
                            )),
                          ]),
                        );
                      },
                    ),
                  ],
                );
              },
            ),
      ),
    ]);
  }

  String _formatSessionLabel(String raw) {
    // Session IDs are ISO timestamps with colons replaced by dashes:
    //   "2026-06-29T10-30-00"
    // We need to convert back to parseable ISO format.
    try {
      // Split on 'T' to separate date and time parts
      final parts = raw.split('T');
      if (parts.length != 2) return raw;
      final datePart = parts[0]; // "2026-06-29" -- already ISO-format
      final timePart = parts[1].replaceAll('-', ':'); // "10-30-00" -> "10:30:00"
      final isoString = '$datePart' 'T' '$timePart';
      final dt = DateTime.parse(isoString);
      return '${dt.day}/${dt.month} ${dt.hour.toString().padLeft(2, '0')}:${dt.minute.toString().padLeft(2, '0')}';
    } catch (_) {
      return raw;
    }
  }
}

// =============================================================================
// Photo viewer (full-screen, swipeable, with share + timestamp)
// =============================================================================

class _PhotoViewerScreen extends StatefulWidget {
  const _PhotoViewerScreen({required this.photos, required this.initialIndex, required this.onShare});
  final List<String> photos;
  final int initialIndex;
  final Future<void> Function(String path) onShare;

  @override
  State<_PhotoViewerScreen> createState() => _PhotoViewerScreenState();
}

class _PhotoViewerScreenState extends State<_PhotoViewerScreen> {
  late PageController _pageController;
  late int _currentIndex;

  @override
  void initState() {
    super.initState();
    _currentIndex = widget.initialIndex;
    _pageController = PageController(initialPage: widget.initialIndex);
  }

  @override
  void dispose() {
    _pageController.dispose();
    super.dispose();
  }

  String _parseTimestamp(String path) {
    try {
      final basename = path.split(Platform.pathSeparator).last;
      // "batbox-2026-06-29T10-30-00-123456.jpg"
      final match = RegExp(r'batbox-(.+)\.jpg').firstMatch(basename);
      if (match != null) {
        final raw = match.group(1)!;
        final cleaned = raw.replaceAll('-', ':').replaceFirst('T', ' ');
        return cleaned.substring(0, 19);
      }
    } catch (_) {}
    return path.split(Platform.pathSeparator).last;
  }

  @override
  Widget build(BuildContext context) {
    if (widget.photos.isEmpty) {
      return Scaffold(backgroundColor: Colors.black, appBar: AppBar(title: const Text('Photo')), body: const Center(child: Text('No photos.')));
    }
    final currentPath = widget.photos[_currentIndex];
    return Scaffold(
      backgroundColor: Colors.black,
      appBar: AppBar(
        backgroundColor: Colors.black87,
        foregroundColor: Colors.white,
        title: Text('${_currentIndex + 1} / ${widget.photos.length}', style: const TextStyle(fontSize: 16)),
        actions: [
          IconButton(icon: const Icon(Icons.share), onPressed: () => widget.onShare(currentPath)),
        ],
      ),
      body: PageView.builder(
        controller: _pageController,
        itemCount: widget.photos.length,
        onPageChanged: (i) => setState(() => _currentIndex = i),
        itemBuilder: (ctx, i) {
          final path = widget.photos[i];
          return Stack(children: [
            Center(child: InteractiveViewer(
              minScale: 0.5, maxScale: 4.0,
              child: Image.file(File(path), fit: BoxFit.contain,
                errorBuilder: (_, __, ___) => const Column(mainAxisAlignment: MainAxisAlignment.center, children: [
                  Icon(Icons.broken_image, size: 64, color: Colors.white54),
                  SizedBox(height: 8),
                  Text('Failed to load', style: TextStyle(color: Colors.white54)),
                ])),
            )),
            // Timestamp at bottom
            Positioned(bottom: 16, left: 0, right: 0,
              child: Center(child: Container(
                padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 6),
                decoration: BoxDecoration(color: Colors.black54, borderRadius: BorderRadius.circular(8)),
                child: Text(_parseTimestamp(path), style: const TextStyle(color: Colors.white, fontSize: 12)),
              )),
            ),
          ]);
        },
      ),
    );
  }
}

// =============================================================================
// Spectrogram painter
// =============================================================================

class _SpectrogramPainter extends CustomPainter {
  final List<List<double>> frames;
  _SpectrogramPainter({required this.frames});

  @override
  void paint(Canvas canvas, Size size) {
    if (frames.isEmpty) return;
    final colW = size.width / frames.length;
    final bins = frames.first.length;
    final binH = size.height / bins;
    for (var col = 0; col < frames.length; col++) {
      final frame = frames[col];
      for (var bin = 0; bin < bins; bin++) {
        final v = (frame[bin]).clamp(0.0, 1.0);
        final color = _magColor(v);
        final x = col * colW;
        final y = size.height - (bin + 1) * binH;
        canvas.drawRect(Rect.fromLTWH(x, y, colW + 1, binH + 1), Paint()..color = color);
      }
    }
  }

  Color _magColor(double v) {
    if (v < 0.25) return Color.lerp(Colors.black, Colors.blue, v * 4)!;
    if (v < 0.5) return Color.lerp(Colors.blue, Colors.green, (v - 0.25) * 4)!;
    if (v < 0.75) return Color.lerp(Colors.green, Colors.yellow, (v - 0.5) * 4)!;
    return Color.lerp(Colors.yellow, Colors.red, (v - 0.75) * 4)!;
  }

  @override
  bool shouldRepaint(covariant _SpectrogramPainter old) => true;
}

// =============================================================================
// Histogram painter
// =============================================================================

class _HistogramPainter extends CustomPainter {
  final List<double> scores;
  final double threshold;
  _HistogramPainter({required this.scores, required this.threshold});

  @override
  void paint(Canvas canvas, Size size) {
    // Threshold line
    final thrY = size.height - (threshold * size.height);
    canvas.drawRect(Rect.fromLTWH(0, thrY, size.width, 1), Paint()..color = Colors.red);

    if (scores.isEmpty) return;
    final barW = size.width / 30; // fixed 30 slots
    for (var i = 0; i < scores.length; i++) {
      final s = scores[i].clamp(0.0, 1.0);
      final h = s * size.height;
      final x = i * barW;
      final y = size.height - h;
      final color = s >= threshold ? Colors.green : Colors.orange;
      canvas.drawRect(Rect.fromLTWH(x, y, barW - 1, h), Paint()..color = color);
    }
  }

  @override
  bool shouldRepaint(covariant _HistogramPainter old) => true;
}

// =============================================================================
// Math helpers
// =============================================================================

double similarityScore(List<double> reference, List<double> candidate) {
  if (reference.isEmpty || candidate.isEmpty) return 0.0;
  final length = min(reference.length, candidate.length);
  double dot = 0, refN = 0, canN = 0;
  for (var i = 0; i < length; i++) {
    final r = reference[i], c = candidate[i];
    dot += r * c; refN += r * r; canN += c * c;
  }
  if (refN == 0 || canN == 0) return 0.0;
  return dot / (sqrt(refN * canN));
}

double normalizedCosineSimRange(List<double> reference, List<double> live, int start, int length) {
  double refSum = 0, liveSum = 0;
  for (var i = 0; i < length; i++) { refSum += reference[i]; liveSum += live[start + i]; }
  final refMean = refSum / length, liveMean = liveSum / length;
  double dot = 0, refN = 0, liveN = 0;
  for (var i = 0; i < length; i++) {
    final r = reference[i] - refMean, c = live[start + i] - liveMean;
    dot += r * c; refN += r * r; liveN += c * c;
  }
  if (refN == 0 || liveN == 0) return 0.0;
  return dot / (sqrt(refN * liveN));
}

double bestSimilarityScore(List<double> reference, List<double> liveSamples, {int? stepOverride}) {
  if (reference.isEmpty || liveSamples.isEmpty) return 0.0;
  final targetLength = min(reference.length, liveSamples.length);
  if (targetLength < 10) return similarityScore(reference, liveSamples);
  final searchSpan = liveSamples.length - targetLength;
  if (searchSpan <= 0) return normalizedCosineSimRange(reference, liveSamples, 0, targetLength);

  if (stepOverride != null && stepOverride > 1) {
    var best = 0.0;
    for (var s = 0; s <= searchSpan; s += stepOverride) {
      final sc = normalizedCosineSimRange(reference, liveSamples, s, targetLength);
      if (sc > best) best = sc;
    }
    return best;
  }

  // Coarse-to-fine
  final coarseStep = max(1, targetLength ~/ 16);
  var best = 0.0;
  var bestStart = 0;
  for (var s = 0; s <= searchSpan; s += coarseStep) {
    final sc = normalizedCosineSimRange(reference, liveSamples, s, targetLength);
    if (sc > best) { best = sc; bestStart = s; }
  }
  if (coarseStep > 1) {
    final fStart = max(0, bestStart - coarseStep);
    final fEnd = min(searchSpan, bestStart + coarseStep);
    for (var s = fStart; s <= fEnd; s++) {
      final sc = normalizedCosineSimRange(reference, liveSamples, s, targetLength);
      if (sc > best) best = sc;
    }
  }
  return best;
}

List<double> pcm16ToDoubles(Uint8List bytes) {
  final samples = <double>[];
  final bd = ByteData.sublistView(bytes);
  for (var i = 0; i + 1 < bytes.length; i += 2) {
    samples.add(bd.getInt16(i, Endian.little) / 32768.0);
  }
  return samples;
}
